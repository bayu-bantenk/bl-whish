/**
 * Dexain (Medela Potentia) Design System theme.
 *
 * Every semantic token reads a CSS variable so the app can switch brand
 * theme (Blue MP / Red AAM) and display mode (light / dark / system) at
 * runtime — see getThemeVars in `src/shared/styles/index.ts`, applied in
 * GlobalProvider. Light-mode defaults live in `global.css`.
 */

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./App.tsx', './src/**/*.{ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        border: 'var(--border)',
        input: 'var(--input)',
        ring: 'var(--ring)',
        background: 'var(--background)',
        foreground: 'var(--foreground)',
        primary: {
          DEFAULT: 'var(--primary)',
          hover: 'var(--primary-hover)',
          press: 'var(--primary-press)',
          soft: 'var(--primary-soft)',
          deep: 'var(--primary-deep)',
          foreground: '#FFFFFF',
        },
        secondary: {
          DEFAULT: 'var(--secondary)',
          foreground: 'var(--secondary-foreground)',
        },
        muted: {
          DEFAULT: 'var(--muted)',
          foreground: 'var(--muted-foreground)',
        },
        accent: {
          DEFAULT: 'var(--accent)',
          foreground: 'var(--accent-foreground)',
        },
        destructive: {
          DEFAULT: 'var(--destructive)',
          soft: 'var(--destructive-soft)',
          foreground: '#FFFFFF',
        },
        success: {
          DEFAULT: 'var(--success)',
          soft: 'var(--success-soft)',
          foreground: '#FFFFFF',
        },
        warning: {
          DEFAULT: 'var(--warning)',
          soft: 'var(--warning-soft)',
          foreground: '#FFFFFF',
        },
        info: {
          DEFAULT: 'var(--info)',
          soft: 'var(--info-soft)',
          foreground: '#FFFFFF',
        },
        card: {
          DEFAULT: 'var(--card)',
          foreground: 'var(--card-foreground)',
        },
        popover: {
          DEFAULT: 'var(--popover)',
          foreground: 'var(--popover-foreground)',
        },
        caption: 'var(--caption)',
        placeholder: 'var(--placeholder)',
        stripe: 'var(--stripe)',
        chip: 'var(--chip)',
      },
      // Dexain radius scale: md (8) is the default for buttons/inputs/chips,
      // lg (12) for content cards, xl (16) for large feature cards.
      borderRadius: {
        DEFAULT: 8,
        xs: 2,
        sm: 4,
        md: 8,
        lg: 12,
        xl: 16,
      },
      // Arimo is the DS primary face. It applies once the font files are
      // bundled (assets/fonts + `npx react-native-asset`); until then RN
      // falls back to the system font, which Arimo is metric-compatible with.
      fontFamily: {
        sans: ['Arimo'],
        display: ['Arimo'],
      },
    },
  },
  plugins: [],
}
