module.exports = {
  printWidth: 85,
  trailingComma: 'es5',
  tabWidth: 2,
  singleQuote: true,
  bracketSpacing: true,
  endOfLine: 'auto',
  semi: false,
}
