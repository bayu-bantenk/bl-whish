module.exports = {
  presets: ['module:@react-native/babel-preset', 'nativewind/babel'],
  plugins: [
    [
      'babel-plugin-module-resolver',
      {
        root: ['./src'],
        extensions: ['.ts', '.tsx', '.js', '.jsx', '.json'],
        alias: {
          '@/components': './src/components',
          '@/utils': './src/shared/utils/utils.ts',
          '@/lib': './src/shared/utils',
          '@/hooks': './src/shared/hooks',
          '@': './src',
        },
      },
    ],
    '@babel/plugin-transform-export-namespace-from',
    // react-native-worklets/plugin MUST be listed last (Reanimated 4).
    'react-native-worklets/plugin',
  ],
}
