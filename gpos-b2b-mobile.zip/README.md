# Mobile APP

Hexenrn is a React Native **0.83 bare CLI** (`@react-native-community/cli`) boilerplate for building mobile apps on Anugrah Argon Medica, written in TypeScript. It mirrors the **Hexagonal + Clean Architecture** design pattern and uses **React Navigation** for navigation and **NativeWind** (Tailwind for React Native) with **react-native-reusables** primitives for the UI.

## Prerequisites

- Node.js >= 22
- React Native 0.83 (bare CLI)
- Ruby + CocoaPods (for iOS builds)
- Xcode (iOS) / Android Studio + JDK 17 (Android)
- Git >= 2.49.0

## Layers

There are several layers in the project:

- **App** — navigation. React Navigation navigators + screen entry files (`src/app/`). Route groups become navigators: `(auth)` = AuthNavigator stack, `(dashboard)` = DashboardNavigator (tabs + stacks).
- **Components** — atomic design UI (`src/components/`): `ui/` (react-native-reusables + NativeWind primitives) < `molecules/` < `organisms/` < `templates/`.
- **Packages** — feature packages under `src/packages/<name>/` with clean-architecture layers:
  - **Domain** — types/entities, value objects, interfaces. No imports from other layers.
  - **Repository** — data access via `RestAPI` (axios). No presentation/usecases.
  - **Usecases** — business logic (`use<Name>UseCase`). No presentation.
  - **Presentation** — screens/views (`.tsx`), zod schemas, hooks, config, FlatList tables, feature components. Imports usecases + `@/components/*`, not repository.
- **Shared** — cross-cutting utilities, hooks, constants, providers, and the `RestAPI` client.

## Getting Started

Install JavaScript dependencies:

```bash
npm install
```

Install iOS native dependencies (macOS only):

```bash
bundle install
cd ios && bundle exec pod install && cd ..
```

Check your environment:

```bash
npx react-native doctor
```

Start the app:

```bash
# iOS
npm run ios

# Android
npm run android
```

add --reset-cache to the above commands if you encounter issues with Metro bundler caching.

To start the Metro bundler on its own:

```bash
npm run start
```

To start the local backend app (if you have the backend source code):

```bash
adb kill-server
adb reverse tcp:4001 tcp:4001
```

## Scripts

- `npm run start` — start Metro bundler
- `npm run ios` / `npm run android` — build and run on a simulator/device
- `npm run test` — run Jest tests
- `npm run lint` — run ESLint
- `npm run validate` — prettier + lint + typecheck
- `npm run typecheck` — TypeScript type check (`tsc --noEmit`)

For committing code, husky + commitlint enforce Conventional Commits and run lint-staged on staged files.

# Attention

Kode sumber Hexenrn APP ini adalah milik dari PT Anugrah Argon Medica. Kode sumber ini besifat rahasia dan penggunaan, penyalinan, atau penyebarluasan yang tidak sah, sebagian atau semuanya ke pihak lain, dilarang.
