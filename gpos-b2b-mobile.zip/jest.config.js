module.exports = {
  preset: 'react-native',
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
  transformIgnorePatterns: [
    'node_modules/(?!(?:@react-native|react-native|react-navigation|@react-navigation|nativewind|react-native-.*|react-native-reanimated|lucide-react-native)/)',
  ],
}
