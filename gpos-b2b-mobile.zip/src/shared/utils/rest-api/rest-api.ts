import { AxiosInstance, AxiosRequestConfig } from 'axios'
import Config from 'react-native-config'

import { serializeParam } from '@/shared/utils'

import { RequestAPI, ResponseAPI } from './types'

function buildUrl(endpoint: string, queryParam?: Record<string, any>): string {
  if (queryParam && Object.keys(queryParam).length > 0) {
    return endpoint + '?' + serializeParam(queryParam)
  }

  return endpoint
}

function toSuccess(res: { status: number; data: any }): ResponseAPI {
  return {
    code: res.status,
    data: res.data,
    message: res.data?.message,
    status: 'success',
  }
}

// Network failures (timeout, no connection) have no `error.response`.
function toError(error: any): ResponseAPI {
  return {
    code: error.response?.status ?? 0,
    data: error.response?.data ?? {},
    message: error.response?.data?.message ?? error.message,
    status: 'error',
  }
}

export class RestAPI implements RequestAPI {
  private http: AxiosInstance

  constructor(http: AxiosInstance, token?: string | null) {
    this.http = http
    this.http.defaults.headers.common['Api-Key'] = `${Config.KONG_API_KEY}`
    if (token) {
      this.http.defaults.headers.common.Authorization = `Bearer ${token}`
      this.http.defaults.timeout = 60000
    }
  }

  async get(
    endpoint: string,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ): Promise<ResponseAPI> {
    try {
      const res = await this.http.get(buildUrl(endpoint, queryParam), config)

      return toSuccess(res)
    } catch (error: any) {
      return toError(error)
    }
  }

  async post(
    endpoint: string,
    body?: Record<string, any>,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ): Promise<ResponseAPI> {
    try {
      const res = await this.http.post(buildUrl(endpoint, queryParam), body, config)

      return toSuccess(res)
    } catch (error: any) {
      return toError(error)
    }
  }

  async put(
    endpoint: string,
    body?: Record<string, any>,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ): Promise<ResponseAPI> {
    try {
      const res = await this.http.put(buildUrl(endpoint, queryParam), body, config)

      return toSuccess(res)
    } catch (error: any) {
      return toError(error)
    }
  }

  async patch(
    endpoint: string,
    body?: Record<string, any>,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ): Promise<ResponseAPI> {
    try {
      const res = await this.http.patch(buildUrl(endpoint, queryParam), body, config)

      return toSuccess(res)
    } catch (error: any) {
      return toError(error)
    }
  }

  async delete(
    endpoint: string,
    bodyparam?: any,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ): Promise<ResponseAPI> {
    try {
      const axiosConfig: AxiosRequestConfig = {
        ...config,
        data: bodyparam,
      }

      const res = await this.http.delete(buildUrl(endpoint, queryParam), axiosConfig)

      return toSuccess(res)
    } catch (error: any) {
      return toError(error)
    }
  }
}
