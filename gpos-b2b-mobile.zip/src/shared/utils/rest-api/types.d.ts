import { AxiosRequestConfig } from 'axios'

export interface RequestAPI {
  get: (
    endpoint: string,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ) => Promise<ResponseAPI>
  post: (
    endpoint: string,
    body?: Record<string, any>,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ) => Promise<ResponseAPI>
  put: (
    endpoint: string,
    body?: Record<string, any>,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ) => Promise<ResponseAPI>
  patch: (
    endpoint: string,
    body?: Record<string, any>,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ) => Promise<ResponseAPI>
  delete: (
    endpoint: string,
    bodyparam?: any,
    queryParam?: Record<string, any>,
    config?: AxiosRequestConfig
  ) => Promise<ResponseAPI>
}

export type ResponseAPI = {
  code: number
  data: Record<string, any>
  message: string
  status: 'success' | 'error'
}
