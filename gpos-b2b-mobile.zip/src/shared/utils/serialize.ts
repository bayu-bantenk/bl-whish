/**
 * Query-string helpers implemented with plain string operations.
 *
 * Deliberately avoids `URLSearchParams`: React Native's built-in
 * implementation is incomplete (no `forEach`/`get`, and `toString()` does
 * not URL-encode), so it behaves differently on device than in Jest/Node.
 */
export const serializeParam = (obj: Record<string, any>): string => {
  return Object.entries(obj)
    .filter(([, value]) => Boolean(value))
    .map(
      ([key, value]) =>
        `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`
    )
    .join('&')
}

export const deserializeParam = (str: string): Record<string, any> => {
  const obj: Record<string, any> = {}

  for (const part of str.replace(/^\?/, '').split('&')) {
    if (!part) continue

    const [key, ...rest] = part.split('=')
    obj[decodeURIComponent(key)] = decodeURIComponent(rest.join('='))
  }

  return obj
}
