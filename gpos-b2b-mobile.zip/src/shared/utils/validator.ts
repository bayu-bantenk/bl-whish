export const isEmail = (email: string) => {
  const regex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/ // eslint-disable-line
  return regex.test(email)
}

export const isPhone = (phone: string) => {
  const regex = /^(^\+62|62|^08)(\d{3,4}-?){2}\d{3,4}$/g
  return regex.test(phone)
}

export const isNumber = (num: string) => {
  const regex = /^\d+$/
  return regex.test(num)
}

export const isIncludeNumber = (str: string) => {
  const regex = /\d/
  return regex.test(str)
}

export const isIncludeCapital = (str: string) => {
  const regex = /[A-Z]/
  return regex.test(str)
}

export const isIncludeSpecialChar = (str: string) => {
  const regex = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/ // eslint-disable-line
  return regex.test(str)
}

export const isOtp = (str: string) => {
  const regex = /^(\d\s*){4}$/g
  return regex.test(str)
}

export const isUUid = (str: string) => {
  const regex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i
  return regex.test(str)
}

export const isTrueBoolean = (str: string) => {
  return /^true$/i.test(str)
}
