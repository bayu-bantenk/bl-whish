export interface SearchParams {
  [key: string]: string | string[] | undefined
}

export interface PathParams {
  [key: string]: string | string[] | undefined
}

export interface IndexPageProps {
  searchParams?: SearchParams
}

export type Option = {
  label: string
  value: string
  icon?: React.ComponentType<{ className?: string }>
}

export interface DataTableFilterOption<TData> {
  id?: string
  label: string
  value: keyof TData | string
  items: Option[]
  isMulti?: boolean
}

export interface DataTableSearchableColumn<TData> {
  id: keyof TData
  title: string
}

export interface DataTableFilterableColumn<
  TData,
> extends DataTableSearchableColumn<TData> {
  options: Option[]
}
