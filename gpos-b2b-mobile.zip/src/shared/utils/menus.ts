import {
  FileClock,
  Home,
  KeySquare,
  LifeBuoy,
  ListTodo,
  type LucideIcon,
  ShieldCheck,
  UserRound,
  Workflow,
} from 'lucide-react-native'

import { dashboardRoute } from '@/shared/constants/routes'
import type { Dictionary } from '@/shared/dictionaries'

/** Dictionary key under `nav` used to translate the item's title/subtitle. */
export type DashNavKey = keyof Dictionary['nav']

export interface DashNav {
  title: string
  url: string
  icon: LucideIcon
  /** Lookup key for translated title/subtitle (see `Dictionary['nav']`). */
  key?: DashNavKey
  /** Short description shown under the title in the "Semua Fitur" menu. */
  subtitle?: string
  color?: string
  isChildren?: boolean
  children?: DashNav[]
  isSubChildren?: boolean
  subChildren?: DashNav[]
}

export const dashNav: DashNav[] = [
  {
    title: 'Home',
    url: dashboardRoute.home,
    icon: Home,
    color: 'text-gray-700',
  },
  {
    title: 'Users',
    url: dashboardRoute.user,
    icon: UserRound,
    color: 'text-gray-700',
  },
  {
    title: 'Roles',
    url: dashboardRoute.role,
    icon: LifeBuoy,
    color: 'text-gray-700',
  },
  {
    title: 'Permission Sets',
    url: dashboardRoute.permissionSet,
    icon: ShieldCheck,
    color: 'text-gray-700',
  },
  {
    title: 'Audit Logs',
    url: dashboardRoute.auditLog,
    icon: FileClock,
    color: 'text-gray-700',
  },
  {
    title: 'Attributes',
    url: dashboardRoute.attribute,
    icon: ListTodo,
    color: 'text-gray-700',
  },
  {
    title: 'API Keys',
    url: dashboardRoute.apiKey,
    icon: KeySquare,
    color: 'text-gray-700',
  },
  {
    title: 'Workflow',
    url: dashboardRoute.workflow,
    icon: Workflow,
    color: 'text-gray-700',
  },
]

export const dashMobileNav: DashNav[] = [
  {
    title: 'Home',
    url: dashboardRoute.home,
    icon: Home,
    key: 'home',
    subtitle: 'Ringkasan aktivitas hari ini',
    color: 'text-gray-700',
  },
  {
    title: 'Users',
    url: dashboardRoute.user,
    icon: UserRound,
    key: 'users',
    subtitle: 'Kelola akun pengguna',
    color: 'text-gray-700',
  },
  {
    title: 'Roles',
    url: dashboardRoute.role,
    icon: LifeBuoy,
    key: 'roles',
    subtitle: 'Kelola peran & hak akses',
    color: 'text-gray-700',
  },
  {
    title: 'Permission Sets',
    url: dashboardRoute.permissionSet,
    icon: ShieldCheck,
    key: 'permissionSets',
    subtitle: 'Kumpulan izin per peran',
    color: 'text-gray-700',
  },
  {
    title: 'Audit Logs',
    url: dashboardRoute.auditLog,
    icon: FileClock,
    key: 'auditLogs',
    subtitle: 'Riwayat aktivitas sistem',
    color: 'text-gray-700',
  },
  {
    title: 'Attributes',
    url: dashboardRoute.attribute,
    icon: ListTodo,
    key: 'attributes',
    subtitle: 'Atribut & konfigurasi data',
    color: 'text-gray-700',
  },
  {
    title: 'API Keys',
    url: dashboardRoute.apiKey,
    icon: KeySquare,
    key: 'apiKeys',
    subtitle: 'Kunci integrasi aplikasi',
    color: 'text-gray-700',
  },
  {
    title: 'Workflow',
    url: dashboardRoute.workflow,
    icon: Workflow,
    key: 'workflow',
    subtitle: 'Alur persetujuan dokumen',
    color: 'text-gray-700',
  },
]
