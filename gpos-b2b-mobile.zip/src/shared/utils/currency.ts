export const formatRupiah = (
  currency: number,
  decimal: number | 0 = 0,
  char?: ',' | '.'
): string => {
  if (typeof currency !== 'number' || isNaN(currency)) {
    return 'Rp0'
  }

  // Use '.' as default separator for thousands if 'char' is not provided
  const thousandsSeparator = char || '.'
  // Use a comma (',') as the fixed decimal separator (standard for IDR presentation)
  const decimalSeparator = ','

  // 1. Convert to string with the specified number of decimal places using toFixed()
  // This also handles rounding.
  const fixedCurrency = currency.toFixed(decimal)

  // 2. Split into integer and fractional parts
  const parts = fixedCurrency.split('.')
  let integerPart = parts[0]
  // The fractional part might be absent if decimal is 0
  const fractionalPart = parts.length > 1 ? parts[1] : ''

  // 3. Apply the thousands separator using regex on the integer part
  // This regex matches every three digits from the end of the string.
  integerPart = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSeparator)

  // 4. Combine parts
  if (decimal > 0) {
    return 'Rp' + integerPart + decimalSeparator + fractionalPart
  } else {
    // Return only the integer part if decimal count is 0
    return 'Rp' + integerPart
  }
}

export const unformatRupiah = (price: string) => {
  try {
    return price.replace(/\D/g, '')
  } catch (error) {
    return '0'
  }
}

export const formatMoney = (amount: number, currency = 'USD', locale = 'en-US') => {
  // Create a NumberFormat object with the specified locale and currency
  const formatter = new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency,
  })

  // Format the amount and return the result
  return formatter.format(amount)
}
