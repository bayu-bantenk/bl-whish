import { classNames } from '../class-names'
import { deserializeParam, serializeParam } from '../serialize'

describe('serializeParam', () => {
  it('serializes an object into a query string', () => {
    expect(serializeParam({ page: 1, search: 'john' })).toBe('page=1&search=john')
  })

  it('drops empty and undefined values', () => {
    expect(serializeParam({ page: 1, search: '', sort: undefined })).toBe('page=1')
  })
})

describe('deserializeParam', () => {
  it('parses a query string back into an object', () => {
    expect(deserializeParam('page=1&search=john')).toEqual({
      page: '1',
      search: 'john',
    })
  })
})

describe('classNames', () => {
  it('joins truthy class names', () => {
    expect(classNames('a', '', 'b')).toBe('a b')
  })
})
