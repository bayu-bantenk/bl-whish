import AsyncStorage from '@react-native-async-storage/async-storage'
import * as Keychain from 'react-native-keychain'

export interface Session {
  id: string
  idx: string
  name: string
  email: string
  access_jwt: string
  access_jwt_exp: number
  refresh_jwt: string
  refresh_jwt_exp: number
}

const SESSION_KEY = 'auth.session'
const TOKEN_SERVICE = 'auth.token'

export async function saveSession(session: Session): Promise<void> {
  await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session))
}

export async function getSession(): Promise<Session | null> {
  const raw = await AsyncStorage.getItem(SESSION_KEY)

  if (!raw) {
    return null
  }

  try {
    return JSON.parse(raw) as Session
  } catch {
    return null
  }
}

export async function clearSession(): Promise<void> {
  await AsyncStorage.removeItem(SESSION_KEY)
}

export async function saveToken(token: string): Promise<void> {
  await Keychain.setGenericPassword('token', token, {
    service: TOKEN_SERVICE,
  })
}

export async function getToken(): Promise<string | null> {
  const credentials = await Keychain.getGenericPassword({
    service: TOKEN_SERVICE,
  })

  if (!credentials) {
    return null
  }

  return credentials.password
}

export async function clearToken(): Promise<void> {
  await Keychain.resetGenericPassword({ service: TOKEN_SERVICE })
}
