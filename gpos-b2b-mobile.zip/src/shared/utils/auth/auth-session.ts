import { create } from 'zustand'

import {
  clearSession,
  clearToken,
  getSession,
  getToken,
  saveSession,
  saveToken,
  Session,
} from './auth-storage'

interface AuthSessionState {
  session: Session | null
  token: string | null
  isAuthenticated: boolean
  /** True once the persisted session has been loaded at app start. */
  isHydrated: boolean
  hydrate: () => Promise<void>
  setSession: (session: Session, token: string) => Promise<void>
  signOut: () => Promise<void>
}

export const useAuthSession = create<AuthSessionState>((set) => ({
  session: null,
  token: null,
  isAuthenticated: false,
  isHydrated: false,
  hydrate: async () => {
    try {
      const [session, token] = await Promise.all([getSession(), getToken()])

      if (session && token) {
        set({ session, token, isAuthenticated: true, isHydrated: true })
        return
      }
    } catch {
      // Corrupt storage entries should not block app start.
    }

    set({ isHydrated: true })
  },
  setSession: async (session, token) => {
    await saveSession(session)
    await saveToken(token)
    set({ session, token, isAuthenticated: true })
  },
  signOut: async () => {
    await clearSession()
    await clearToken()
    set({ session: null, token: null, isAuthenticated: false })
  },
}))
