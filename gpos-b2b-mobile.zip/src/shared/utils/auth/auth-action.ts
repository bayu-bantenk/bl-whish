import { Login } from '@/packages/auth/domain/auth'
import useAuthUseCase from '@/packages/auth/usecases/usecase'

import { useAuthSession } from './auth-session'
import { getSession, Session } from './auth-storage'

export async function postLogin(payload: Login) {
  // useAuthUseCase is a plain factory (not a React hook) despite its name.
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const response: any = await useAuthUseCase().login(payload)

  if (response.code && response.code !== 200) {
    return { success: false, ...response }
  }

  const session = response.data as Session

  await useAuthSession.getState().setSession(session, session.access_jwt)

  return { success: true, ...response }
}

export async function getStoredSession(): Promise<Session | null> {
  return getSession()
}

export async function postLogout(): Promise<void> {
  const { token, signOut } = useAuthSession.getState()

  try {
    if (token) {
      // eslint-disable-next-line react-hooks/rules-of-hooks
      await useAuthUseCase(token).logout({ token })
    }
  } catch {
    // Server-side logout is best-effort — never block signing out locally.
  }

  await signOut()
}
