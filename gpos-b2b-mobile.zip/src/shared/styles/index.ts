import AsyncStorage from '@react-native-async-storage/async-storage'
import { vars } from 'nativewind'
import { useMemo } from 'react'
import { useColorScheme } from 'react-native'
import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

/**
 * Dexain (Medela Potentia) Design System — themeable palette.
 *
 * Two axes, both persisted in the theme store:
 *  - brand theme:  Blue MP (default) | Red AAM
 *  - display mode: light | dark | system
 *
 * Class-based styling reads CSS variables (see `getThemeVars`), so both
 * axes restyle `bg-background`, `bg-primary`, `bg-card`, ... everywhere at
 * once. Inside components use `useDexain()` for JS-prop colors.
 */

export type SchemeId = 'light' | 'dark'
export type ThemeMode = SchemeId | 'system'
export type ThemeId = 'blue' | 'red'

const neutralPalettes = {
  light: {
    fg1: '#191B1D',
    fg2: '#6B6B6B',
    fg3: '#959697',
    fg4: '#8E98A8',
    fgInvert: '#FFFFFF',

    bgApp: '#F0F2F5',
    bgSurface: '#FFFFFF',
    bgMuted: '#F2F2F2',
    bgSubtle: '#F4F7FA',
    bgQuiet: '#FAFAFA',

    border: '#D2DEEB',
    borderSoft: '#E8E8E8',
    borderStrong: '#414141',

    success: '#007A3C',
    successSoft: '#E6F3EC',
    warn: '#C54600',
    warnSoft: '#FEF1E6',
    danger: '#E93742',
    dangerSoft: '#FDE8E9',
    info: '#0B75BE',
    infoSoft: '#E7F1F9',

    rowStripe: '#F2F5F9',
    rowHover: '#E9EEF5',
    chipBg: '#E9EBF8',
  },
  dark: {
    fg1: '#F2F4F6',
    fg2: '#B3B9BF',
    fg3: '#8A9099',
    fg4: '#6F7987',
    fgInvert: '#FFFFFF',

    bgApp: '#0F1214',
    bgSurface: '#1A1D21',
    bgMuted: '#24282D',
    bgSubtle: '#20252B',
    bgQuiet: '#16191D',

    border: '#2C3238',
    borderSoft: '#262B30',
    borderStrong: '#C8CDD2',

    success: '#2FA96A',
    successSoft: '#12301F',
    warn: '#E06A1F',
    warnSoft: '#3A2510',
    danger: '#F0545E',
    dangerSoft: '#38181C',
    info: '#3D96D4',
    infoSoft: '#10283C',

    rowStripe: '#1E2328',
    rowHover: '#242A31',
    chipBg: '#262C35',
  },
}

type BrandSchemeScale = {
  soft: string
  deep: string
  /** Readable brand tint for text/icons on the accent surface. */
  accentFg: string
}

type BrandTheme = {
  label: string
  brand: string
  brandHover: string
  brandPress: string
  brandSolidText: string
  scheme: Record<SchemeId, BrandSchemeScale>
}

/** Available brand themes. `blue` is the Medela Potentia default. */
export const brandThemes: Record<ThemeId, BrandTheme> = {
  blue: {
    label: 'Blue MP (Default)',
    brand: '#0060AC',
    brandHover: '#00528F',
    brandPress: '#003E6E',
    brandSolidText: '#FFFFFF',
    scheme: {
      light: { soft: '#E7F1F9', deep: '#22335C', accentFg: '#0060AC' },
      dark: { soft: '#0E2233', deep: '#16233F', accentFg: '#7DB8E8' },
    },
  },
  red: {
    label: 'Red AAM',
    brand: '#DC2127',
    brandHover: '#B91B20',
    brandPress: '#951519',
    brandSolidText: '#FFFFFF',
    scheme: {
      light: { soft: '#FCE9EA', deep: '#4E1F26', accentFg: '#DC2127' },
      dark: { soft: '#331416', deep: '#361418', accentFg: '#F08A90' },
    },
  },
}

function buildPalette(themeId: ThemeId, scheme: SchemeId) {
  const theme = brandThemes[themeId]
  const brandScale = theme.scheme[scheme]

  return {
    ...neutralPalettes[scheme],
    brand: theme.brand,
    brandHover: theme.brandHover,
    brandPress: theme.brandPress,
    brandSoft: brandScale.soft,
    brandDeep: brandScale.deep,
    brandSolidText: theme.brandSolidText,
    accentFg: brandScale.accentFg,
    scheme,
  }
}

/**
 * Static palette (blue theme, light mode) for places that cannot use hooks.
 * Inside components prefer `useDexain()` so colors follow the active theme.
 */
export const dexain = buildPalette('blue', 'light')

export type DexainColor = keyof typeof dexain

type ThemeState = {
  themeId: ThemeId
  mode: ThemeMode
  setThemeId: (themeId: ThemeId) => void
  setMode: (mode: ThemeMode) => void
}

/** Persisted theme selection: brand + display mode. */
export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      themeId: 'blue',
      mode: 'system',
      setThemeId: (themeId) => set({ themeId }),
      setMode: (mode) => set({ mode }),
    }),
    {
      name: 'app.theme',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
)

/** The light/dark scheme currently in effect (resolves 'system'). */
export function useResolvedScheme(): SchemeId {
  const mode = useThemeStore((state) => state.mode)
  const system = useColorScheme()

  if (mode === 'system') {
    return system === 'dark' ? 'dark' : 'light'
  }

  return mode
}

/** Palette that follows the active brand theme and display mode. */
export function useDexain() {
  const themeId = useThemeStore((state) => state.themeId)
  const scheme = useResolvedScheme()

  return useMemo(() => buildPalette(themeId, scheme), [themeId, scheme])
}

/**
 * NativeWind CSS variables for the active theme + scheme. Applied to the
 * root View in GlobalProvider so every semantic class follows the theme.
 */
export function getThemeVars(themeId: ThemeId, scheme: SchemeId) {
  const palette = buildPalette(themeId, scheme)

  return vars({
    /* brand */
    '--primary': palette.brand,
    '--primary-hover': palette.brandHover,
    '--primary-press': palette.brandPress,
    '--primary-soft': palette.brandSoft,
    '--primary-deep': palette.brandDeep,
    '--accent': palette.brandSoft,
    '--accent-foreground': palette.accentFg,
    '--ring': palette.brand,

    /* neutrals */
    '--background': palette.bgApp,
    '--foreground': palette.fg1,
    '--card': palette.bgSurface,
    '--card-foreground': palette.fg1,
    '--popover': palette.bgSurface,
    '--popover-foreground': palette.fg1,
    '--secondary': palette.bgSubtle,
    '--secondary-foreground': palette.fg1,
    '--muted': palette.bgMuted,
    '--muted-foreground': palette.fg2,
    '--border': palette.border,
    '--input': palette.border,
    '--caption': palette.fg3,
    '--placeholder': palette.fg4,
    '--stripe': palette.rowStripe,
    '--chip': palette.chipBg,

    /* semantic */
    '--success': palette.success,
    '--success-soft': palette.successSoft,
    '--warning': palette.warn,
    '--warning-soft': palette.warnSoft,
    '--destructive': palette.danger,
    '--destructive-soft': palette.dangerSoft,
    '--info': palette.info,
    '--info-soft': palette.infoSoft,
  })
}
