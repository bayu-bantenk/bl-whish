import Config from 'react-native-config'

export const config = {
  apiHost: Config.API_HOST,
  appUrl: Config.APP_URL,
  appKey: Config.APP_KEY,
  imageBaseUrl: Config.CDN_URL,
  kongApiKey: Config.KONG_API_KEY,
}
