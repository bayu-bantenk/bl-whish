export const homeRoute = 'Home'

export const authRoute = {
  login: 'Login',
  register: 'Register',
  forgot: 'Forgot',
  reset: 'Reset',
}

export const dashboardRoute = {
  home: 'Home',
  user: 'User',
  userCreate: 'UserCreate',
  userUpdate: 'UserUpdate',
  profile: 'Profile',
  role: 'Role',
  roleCreate: 'RoleCreate',
  roleUpdate: 'RoleUpdate',
  permissionSet: 'PermissionSet',
  permissionSetCreate: 'PermissionSetCreate',
  permissionSetUpdate: 'PermissionSetUpdate',
  auditLog: 'AuditLog',
  auditLogDetail: 'AuditLogDetail',
  attribute: 'Attribute',
  attributeCreate: 'AttributeCreate',
  attributeUpdate: 'AttributeUpdate',
  apiKey: 'ApiKey',
  apiKeyCreate: 'ApiKeyCreate',
  apiKeyUpdate: 'ApiKeyUpdate',
  workflow: 'Workflow',
  workflowDetail: 'WorkflowDetail',
}
