export const authApi = {
  login: '/auth/login',
  logout: '/auth/logout',
  refreshToken: '/auth/refresh-token',
}
