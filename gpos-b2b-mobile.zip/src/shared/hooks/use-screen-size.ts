import { useWindowDimensions } from 'react-native'

export const useScreenSize = () => {
  const { width } = useWindowDimensions()

  return {
    screenWidth: width,
    isMobile: width < 768,
    isDesktop: width >= 768,
  }
}

export default useScreenSize
