import { useColorScheme } from 'nativewind'

export { useColorScheme }

export default useColorScheme
