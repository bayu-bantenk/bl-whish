import React, { SetStateAction } from 'react'

export const LoadingFullContext = React.createContext({
  loadingFull: '0',
  setLoadingFull: (value: SetStateAction<string>) => {},
})
