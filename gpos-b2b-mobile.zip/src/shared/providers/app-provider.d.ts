export interface IAppProvider {
  screenWidth: number
  isMobile: boolean
  isDesktop: boolean
}
