import { createContext, ReactNode, useContext } from 'react'

import { useScreenSize } from '@/shared/hooks'

import { IAppProvider } from './app-provider.d'

const AppContextProvider = createContext<IAppProvider | undefined>(undefined)

export const AppProvider = ({
  children,
}: {
  children: ReactNode
  // `auth` is accepted but unused in native — kept for API parity with the
  // web template. Native handles auth gating through the navigator.
  auth?: 'public' | 'private'
}) => {
  const { screenWidth, isMobile, isDesktop } = useScreenSize()

  const contextState = {
    screenWidth,
    isMobile,
    isDesktop,
  }

  return (
    <AppContextProvider.Provider value={contextState}>
      {children}
    </AppContextProvider.Provider>
  )
}

export const useAppProvider = () => {
  const context = useContext(AppContextProvider)

  if (context === undefined) {
    throw new Error('useAppProvider must be used within a AppProvider')
  }

  return context
}
