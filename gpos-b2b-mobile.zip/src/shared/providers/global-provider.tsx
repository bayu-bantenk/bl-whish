import { ReactNode, useState } from 'react'
import { StatusBar, View } from 'react-native'
import Toast from 'react-native-toast-message'

import { LoadingFullContext } from '@/shared/contexts/loading-full'
import {
  getThemeVars,
  useDexain,
  useResolvedScheme,
  useThemeStore,
} from '@/shared/styles'

const GlobalProvider = ({ children }: { children: ReactNode }) => {
  const [loadingFull, setLoadingFull] = useState('0')
  const loadingValue = { loadingFull, setLoadingFull }

  const themeId = useThemeStore((state) => state.themeId)
  const scheme = useResolvedScheme()
  const palette = useDexain()

  return (
    <LoadingFullContext.Provider value={loadingValue}>
      {/* Base status bar for the resolved scheme; screens with their own
          chrome (e.g. Home's navy header) override it while focused. */}
      <StatusBar
        animated
        barStyle={scheme === 'dark' ? 'light-content' : 'dark-content'}
        backgroundColor={palette.bgApp}
      />
      {/* Theme wrapper: applies the active brand + scheme variables. */}
      <View className="flex-1 bg-background" style={getThemeVars(themeId, scheme)}>
        {children}
        <Toast />
      </View>
    </LoadingFullContext.Provider>
  )
}

export default GlobalProvider
