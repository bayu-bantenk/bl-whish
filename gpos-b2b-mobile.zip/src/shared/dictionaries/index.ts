import AsyncStorage from '@react-native-async-storage/async-storage'
import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

import { en } from './en'
import { id } from './id'

/**
 * App localization: English (default) and Indonesian.
 *
 * Mirrors the theme store pattern in `@/shared/styles` — a persisted zustand
 * store plus a hook. Screens call `useTranslation()` and read strings from
 * the typed dictionary:
 *
 *   const { t } = useTranslation()
 *   <Text>{t.settings.title}</Text>
 *
 * Strings with `{placeholders}` are resolved with `translate`:
 *
 *   translate(t.home.tasksRemaining, { count: 3 })
 */

export type Language = 'en' | 'id'
export type Dictionary = typeof en

export const defaultLanguage: Language = 'en'

export const dictionaries: Record<Language, Dictionary> = { en, id }

/** Resolves `{placeholder}` tokens in a dictionary string. */
export function translate(
  template: string,
  params: Record<string, string | number>
): string {
  return template.replace(/\{(\w+)\}/g, (match, key) =>
    key in params ? String(params[key]) : match
  )
}

type LanguageState = {
  language: Language
  setLanguage: (language: Language) => void
}

/** Persisted language selection. English is the default. */
export const useLanguageStore = create<LanguageState>()(
  persist(
    (set) => ({
      language: defaultLanguage,
      setLanguage: (language) => set({ language }),
    }),
    {
      name: 'app.language',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
)

/** Dictionary for places that cannot use hooks. */
export function getDictionary(language: Language): Dictionary {
  return dictionaries[language]
}

/** Active dictionary + language controls, re-rendering on language change. */
export function useTranslation() {
  const language = useLanguageStore((state) => state.language)
  const setLanguage = useLanguageStore((state) => state.setLanguage)

  return { t: dictionaries[language], language, setLanguage }
}

export { en } from './en'
export { id } from './id'
