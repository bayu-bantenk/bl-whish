import * as React from 'react'
import { View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'

import { Header } from '@/components/organisms/header/header'

type DashboardLayoutProps = {
  title?: string
  showBack?: boolean
  headerRight?: React.ReactNode
  children?: React.ReactNode
}

export function DashboardLayout({
  title,
  showBack,
  headerRight,
  children,
}: DashboardLayoutProps) {
  return (
    <View className="flex-1 bg-background">
      {/* White strip behind the status bar so it merges with the header. */}
      <SafeAreaView edges={['top']} className="bg-card" />
      {title ? (
        <Header title={title} showBack={showBack}>
          {headerRight}
        </Header>
      ) : null}
      <View className="flex-1">{children}</View>
    </View>
  )
}
