import * as React from 'react'
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native'
import Config from 'react-native-config'
import { SafeAreaView } from 'react-native-safe-area-context'

import { Separator } from '@/components/ui/separator'
import { Text } from '@/components/ui/text'

import pkg from '../../../package.json'

type AuthLayoutProps = {
  title?: string
  description?: string
  /** Brand name shown next to the logo tile. Defaults to APP_NAME from .env. */
  brandName?: string
  /** Small uppercase tagline under the brand name. */
  brandTagline?: string
  children?: React.ReactNode
}

export function AuthLayout({
  title,
  description,
  brandName = Config.APP_NAME ?? 'Hexenrn',
  brandTagline = 'Mobile Platform',
  children,
}: AuthLayoutProps) {
  const initials = brandName.slice(0, 2)

  return (
    <SafeAreaView className="flex-1 bg-background">
      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerClassName="flex-grow px-6 py-8"
          keyboardShouldPersistTaps="handled"
        >
          <View className="w-full max-w-sm flex-1 self-center">
            {/* Brand */}
            <View className="mb-10 mt-12 flex-row items-center gap-3">
              <View className="h-12 w-12 items-center justify-center rounded-md bg-primary">
                <Text className="text-xl font-bold text-primary-foreground">
                  {initials}
                </Text>
              </View>
              <View>
                <Text className="text-2xl font-bold text-primary">{brandName}</Text>
                <Text className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  {brandTagline}
                </Text>
              </View>
            </View>

            {/* Heading */}
            {title || description ? (
              <View className="mb-8 gap-1.5">
                {title ? (
                  <Text className="text-2xl font-bold text-foreground">{title}</Text>
                ) : null}
                {description ? <Text variant="muted">{description}</Text> : null}
              </View>
            ) : null}

            {children}

            {/* Footer pinned to the bottom of the screen */}
            <View className="flex-1" />
            <View className="mt-12">
              <Separator className="mb-4" />
              <View className="flex-row items-center justify-between">
                <Text className="text-xs text-muted-foreground">
                  Release {__DEV__ ? 'DEV' : 'PROD'} · v{pkg.version}
                </Text>
                <Text className="text-xs font-bold italic text-primary">
                  anugrah argon medica
                </Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}
