import { CircleAlert, type LucideIcon } from 'lucide-react-native'
import * as React from 'react'
import { View } from 'react-native'

import { Button } from '@/components/ui/button'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Spinner } from '@/components/ui/spinner'
import { Text } from '@/components/ui/text'
import { useTranslation } from '@/shared/dictionaries'
import { useDexain } from '@/shared/styles'
import { cn } from '@/utils'

export type ConfirmModalTone =
  'primary' | 'destructive' | 'warning' | 'success' | 'info'

const tileBg: Record<ConfirmModalTone, string> = {
  primary: 'bg-accent',
  destructive: 'bg-destructive-soft',
  warning: 'bg-warning-soft',
  success: 'bg-success-soft',
  info: 'bg-info-soft',
}

const solidButton: Record<ConfirmModalTone, string> = {
  primary: 'bg-primary active:bg-primary-press',
  destructive: 'bg-destructive active:opacity-90',
  warning: 'bg-warning active:opacity-90',
  success: 'bg-success active:opacity-90',
  info: 'bg-info active:opacity-90',
}

type ConfirmModalProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  title?: string
  description?: string
  /** Icon shown in the soft circular tile. Defaults to an alert circle. */
  icon?: LucideIcon
  tone?: ConfirmModalTone
  confirmText?: string
  /** Omit to render a single full-width button (alert mode). */
  cancelText?: string
  loading?: boolean
  /** Omit for pure alerts — the button then simply closes the modal. */
  onConfirm?: () => void
}

/**
 * Dexain alert/confirm modal: centered soft icon tile, centered title and
 * description, tone-colored actions. Use in place of React Native's
 * `Alert.alert` so dialogs match the design system on every platform.
 */
export function ConfirmModal({
  open,
  onOpenChange,
  title,
  description,
  icon: Icon = CircleAlert,
  tone = 'destructive',
  confirmText,
  cancelText,
  loading = false,
  onConfirm,
}: ConfirmModalProps) {
  const palette = useDexain()
  const { t } = useTranslation()
  const resolvedTitle = title ?? t.common.warning
  const resolvedConfirmText = confirmText ?? t.common.ok
  const tileIconColor: Record<ConfirmModalTone, string> = {
    primary: palette.brand,
    destructive: palette.danger,
    warning: palette.warn,
    success: palette.success,
    info: palette.info,
  }
  const iconTint = tileIconColor[tone]

  const handleConfirm = () => {
    if (onConfirm) {
      onConfirm()
    } else {
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="items-center gap-4 p-6">
        <View
          className={cn(
            'h-14 w-14 items-center justify-center rounded-full',
            tileBg[tone]
          )}
        >
          <Icon size={26} color={iconTint} />
        </View>

        <View className="items-center gap-1.5">
          <Text className="text-lg font-bold">{resolvedTitle}</Text>
          {description ? (
            <Text className="text-center text-sm text-muted-foreground">
              {description}
            </Text>
          ) : null}
        </View>

        <View className="w-full flex-row gap-3 pt-1">
          {cancelText ? (
            <Button
              variant="outline"
              className="flex-1"
              disabled={loading}
              onPress={() => onOpenChange(false)}
            >
              <Text className="font-semibold">{cancelText}</Text>
            </Button>
          ) : null}
          <Button
            className={cn('flex-1', solidButton[tone])}
            disabled={loading}
            onPress={handleConfirm}
          >
            {loading ? <Spinner className="mr-2" color={palette.fgInvert} /> : null}
            <Text className="font-bold text-primary-foreground">
              {resolvedConfirmText}
            </Text>
          </Button>
        </View>
      </DialogContent>
    </Dialog>
  )
}
