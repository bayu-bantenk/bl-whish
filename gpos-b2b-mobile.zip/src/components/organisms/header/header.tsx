import { useNavigation } from '@react-navigation/native'
import { ChevronLeft } from 'lucide-react-native'
import * as React from 'react'
import { Pressable, View } from 'react-native'

import { Separator } from '@/components/ui/separator'
import { Text } from '@/components/ui/text'
import { useDexain } from '@/shared/styles'

type HeaderProps = {
  title?: string
  showBack?: boolean
  children?: React.ReactNode
}

export function Header({ title, showBack = true, children }: HeaderProps) {
  const navigation = useNavigation()
  const palette = useDexain()
  const canGoBack = showBack && navigation.canGoBack()

  return (
    <View className="bg-card">
      <View className="h-14 flex-row items-center justify-between gap-2 px-4">
        <View className="flex-1 flex-row items-center gap-2">
          {canGoBack && (
            <Pressable
              accessibilityRole="button"
              onPress={() => navigation.goBack()}
              className="h-9 w-9 items-center justify-center rounded-lg"
            >
              <ChevronLeft size={22} color={palette.fg1} />
            </Pressable>
          )}
          {title ? (
            <Text className="text-lg font-semibold" numberOfLines={1}>
              {title}
            </Text>
          ) : null}
        </View>
        {children ? (
          <View className="flex-row items-center gap-2">{children}</View>
        ) : null}
      </View>
      <Separator />
    </View>
  )
}
