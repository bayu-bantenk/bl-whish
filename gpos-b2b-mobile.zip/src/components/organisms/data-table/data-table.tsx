import * as React from 'react'
import { FlatList, Pressable, RefreshControl, View } from 'react-native'

import { Spinner } from '@/components/ui/spinner'
import { Text } from '@/components/ui/text'
import { useTranslation } from '@/shared/dictionaries'
import { cn } from '@/utils'

export type DataTableColumn<T> = {
  id: string
  /** Column label, rendered uppercase in the navy header row. */
  header: string
  accessorKey?: keyof T
  /** Secondary muted line under the primary value (e.g. customer name). */
  subAccessorKey?: keyof T
  /** Custom cell renderer — use for chips, colored values, etc. */
  cell?: (row: T) => React.ReactNode
  align?: 'left' | 'right'
  /** Relative column width. Defaults to 1. */
  flex?: number
}

type DataTableProps<T> = {
  data: T[]
  columns: DataTableColumn<T>[]
  keyExtractor?: (item: T, index: number) => string
  isLoading?: boolean
  emptyMessage?: string
  onRefresh?: () => void
  refreshing?: boolean
  onRowPress?: (row: T) => void
  onRowLongPress?: (row: T) => void
  contentContainerClassName?: string
}

function DefaultCell<T>({ column, row }: { column: DataTableColumn<T>; row: T }) {
  const value = column.accessorKey ? row[column.accessorKey] : undefined
  const sub = column.subAccessorKey ? row[column.subAccessorKey] : undefined

  return (
    <View className={column.align === 'right' ? 'items-end' : undefined}>
      <Text className="text-sm font-bold" numberOfLines={1}>
        {value == null || value === '' ? '-' : String(value)}
      </Text>
      {sub != null && sub !== '' ? (
        <Text className="mt-0.5 text-xs text-muted-foreground" numberOfLines={1}>
          {String(sub)}
        </Text>
      ) : null}
    </View>
  )
}

/**
 * Dexain table: navy header row with uppercase white labels, zebra-striped
 * rows, two-line cells via `subAccessorKey`, chips via `cell`. The tabular
 * counterpart of `CardList` — pair them behind a list/table view toggle.
 */
function DataTable<T>({
  data,
  columns,
  keyExtractor,
  isLoading = false,
  emptyMessage,
  onRefresh,
  refreshing = false,
  onRowPress,
  onRowLongPress,
  contentContainerClassName,
}: DataTableProps<T>) {
  const { t } = useTranslation()
  const resolvedEmptyMessage = emptyMessage ?? t.common.noData

  if (isLoading && data.length === 0) {
    return (
      <View className="flex-1 items-center justify-center py-12">
        <Spinner size="large" />
      </View>
    )
  }

  const defaultKeyExtractor = (_item: T, index: number) => String(index)

  return (
    <View className="flex-1 overflow-hidden rounded-lg border border-border bg-card">
      {/* Header row */}
      <View className="flex-row items-center gap-2 bg-primary-deep px-3.5 py-3">
        {columns.map((column) => (
          <Text
            key={column.id}

            style={{ flex: column.flex ?? 1 }}
            className={cn(
              'text-xs font-bold uppercase tracking-wide text-primary-foreground',
              column.align === 'right' && 'text-right'
            )}
          >
            {column.header}
          </Text>
        ))}
      </View>

      <FlatList
        data={data}
        keyExtractor={keyExtractor ?? defaultKeyExtractor}
        contentContainerClassName={contentContainerClassName}
        refreshControl={
          onRefresh ? (
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          ) : undefined
        }
        ItemSeparatorComponent={() => <View className="h-px bg-border/60" />}
        renderItem={({ item, index }) => (
          <Pressable
            accessibilityRole={onRowPress ? 'button' : undefined}
            disabled={!onRowPress && !onRowLongPress}
            onPress={onRowPress ? () => onRowPress(item) : undefined}
            onLongPress={onRowLongPress ? () => onRowLongPress(item) : undefined}
            className={cn(
              'flex-row items-center gap-2 px-3.5 py-3',
              index % 2 === 1 && 'bg-stripe',
              onRowPress && 'active:bg-accent'
            )}
          >
            {columns.map((column) => (
              <View
                key={column.id}

                style={{ flex: column.flex ?? 1 }}
                className={column.align === 'right' ? 'items-end' : undefined}
              >
                {column.cell ? (
                  column.cell(item)
                ) : (
                  <DefaultCell column={column} row={item} />
                )}
              </View>
            ))}
          </Pressable>
        )}
        ListEmptyComponent={
          <View className="items-center justify-center py-12">
            <Text variant="muted">{resolvedEmptyMessage}</Text>
          </View>
        }
      />
    </View>
  )
}

export { DataTable }
