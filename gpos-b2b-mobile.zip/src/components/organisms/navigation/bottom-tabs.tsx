import type { LucideIcon } from 'lucide-react-native'
import * as React from 'react'
import { View } from 'react-native'

type TabBarIconProps = {
  icon: LucideIcon
  color: string
  size?: number
  focused?: boolean
}

/**
 * Reusable tab bar icon renderer. The tab navigator itself lives in
 * `src/app/(dashboard)/dashboard-navigator.tsx`; this keeps icon rendering
 * consistent and light per the atomic hierarchy.
 */
export function TabBarIcon({ icon: Icon, color, size = 22 }: TabBarIconProps) {
  return (
    <View className="items-center justify-center">
      <Icon size={size} color={color} />
    </View>
  )
}
