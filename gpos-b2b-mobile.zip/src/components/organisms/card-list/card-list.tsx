import * as React from 'react'
import { FlatList, RefreshControl, View } from 'react-native'

import {
  ListItemCard,
  type ListItemCardProps,
} from '@/components/molecules/list-item-card/list-item-card'
import { Spinner } from '@/components/ui/spinner'
import { Text } from '@/components/ui/text'
import { useTranslation } from '@/shared/dictionaries'

type CardListProps<T> = {
  data: T[]
  /** Maps a row to ListItemCard props (title, subtitle, value, status...). */
  item: (row: T, index: number) => ListItemCardProps
  keyExtractor?: (item: T, index: number) => string
  isLoading?: boolean
  emptyMessage?: string
  onRefresh?: () => void
  refreshing?: boolean
  /** Section header, e.g. "Detail kontrabon". */
  header?: string
  /** Right-aligned header caption, e.g. "12 dari 118 invoice". */
  headerRight?: string
  contentContainerClassName?: string
}

/**
 * Dexain card list: a FlatList of ListItemCard rows with an optional
 * section-header row. Replaces tabular lists on mobile screens.
 */
function CardList<T>({
  data,
  item,
  keyExtractor,
  isLoading = false,
  emptyMessage,
  onRefresh,
  refreshing = false,
  header,
  headerRight,
  contentContainerClassName,
}: CardListProps<T>) {
  const { t } = useTranslation()
  const resolvedEmptyMessage = emptyMessage ?? t.common.noData

  if (isLoading && data.length === 0) {
    return (
      <View className="flex-1 items-center justify-center py-12">
        <Spinner size="large" />
      </View>
    )
  }

  const defaultKeyExtractor = (_item: T, index: number) => String(index)

  return (
    <FlatList
      data={data}
      keyExtractor={keyExtractor ?? defaultKeyExtractor}
      contentContainerClassName={contentContainerClassName ?? 'gap-2.5 pb-4'}
      refreshControl={
        onRefresh ? (
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        ) : undefined
      }
      ListHeaderComponent={
        header || headerRight ? (
          <View className="mb-1 flex-row items-center justify-between">
            {header ? <Text className="text-sm font-bold">{header}</Text> : <View />}
            {headerRight ? (
              <Text className="text-xs text-muted-foreground">{headerRight}</Text>
            ) : null}
          </View>
        ) : null
      }
      renderItem={({ item: row, index }) => <ListItemCard {...item(row, index)} />}
      ListEmptyComponent={
        <View className="items-center justify-center py-12">
          <Text variant="muted">{resolvedEmptyMessage}</Text>
        </View>
      }
    />
  )
}

export { CardList }
