import { Check, X } from 'lucide-react-native'
import * as React from 'react'
import { Modal, Pressable, ScrollView, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'

import { Text } from '@/components/ui/text'
import { useTranslation } from '@/shared/dictionaries'
import { useDexain } from '@/shared/styles'
import { cn } from '@/utils'

export type SelectSheetOption<V> = {
  value: V
  label: string
  /** Muted second line, e.g. "Aktif · 118 invoice". */
  description?: string
}

type SelectSheetProps<V> = {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  options: SelectSheetOption<V>[]
  value?: V | null
  onSelect: (value: V) => void
  emptyMessage?: string
}

/**
 * Dexain option picker: a bottom sheet with a bold title, circular close
 * button, and option rows — the selected one highlighted with a soft tint
 * and a check mark. The standard replacement for dropdowns on mobile.
 */
function SelectSheet<V extends string | number>({
  open,
  onOpenChange,
  title,
  options,
  value,
  onSelect,
  emptyMessage,
}: SelectSheetProps<V>) {
  const palette = useDexain()
  const insets = useSafeAreaInsets()
  const { t } = useTranslation()
  const resolvedEmptyMessage = emptyMessage ?? t.common.noOptions

  const pick = (next: V) => {
    onSelect(next)
    onOpenChange(false)
  }

  return (
    <Modal
      visible={open}
      transparent
      statusBarTranslucent
      animationType="slide"
      onRequestClose={() => onOpenChange(false)}
    >
      <View className="flex-1 justify-end">
        {/* Backdrop as a sibling (not a parent) so its press handling never
            competes with the sheet's scroll/press gestures. */}
        <Pressable
          accessibilityLabel={t.common.close}
          className="absolute bottom-0 left-0 right-0 top-0 bg-black/50"
          onPress={() => onOpenChange(false)}
        />
        <View
          className="rounded-t-[24px] bg-card"
          style={{ paddingBottom: Math.max(insets.bottom, 8) }}
        >
          {/* Header */}
          <View className="flex-row items-center justify-between px-5 pb-3 pt-5">
            <Text className="text-lg font-bold">{title}</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={t.common.close}
              onPress={() => onOpenChange(false)}
              className="h-9 w-9 items-center justify-center rounded-full bg-muted active:bg-accent"
            >
              <X size={18} color={palette.fg2} />
            </Pressable>
          </View>

          <ScrollView className="max-h-[420px]" bounces={false}>
            {options.length === 0 ? (
              <Text variant="muted" className="px-5 py-8 text-center">
                {resolvedEmptyMessage}
              </Text>
            ) : (
              options.map((option, index) => {
                const selected = option.value === value

                return (
                  <Pressable
                    key={String(option.value)}
                    accessibilityRole="button"
                    onPress={() => pick(option.value)}
                    className={cn(
                      'flex-row items-center justify-between px-5 py-3.5',
                      selected ? 'bg-accent' : 'active:bg-secondary',
                      index < options.length - 1 && 'border-b border-border/60'
                    )}
                  >
                    <View className="flex-1 pr-3">
                      <Text className="text-base font-bold" numberOfLines={1}>
                        {option.label}
                      </Text>
                      {option.description ? (
                        <Text
                          className="mt-0.5 text-xs text-muted-foreground"
                          numberOfLines={1}
                        >
                          {option.description}
                        </Text>
                      ) : null}
                    </View>
                    {selected ? <Check size={20} color={palette.brand} /> : null}
                  </Pressable>
                )
              })
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  )
}

export { SelectSheet }
