import { cva, type VariantProps } from 'class-variance-authority'
import * as React from 'react'
import { Text as RNText } from 'react-native'

import { cn } from '@/utils'

const textVariants = cva('text-base text-foreground', {
  variants: {
    variant: {
      default: 'text-foreground',
      muted: 'text-muted-foreground',
      destructive: 'text-destructive',
    },
  },
  defaultVariants: {
    variant: 'default',
  },
})

type TextProps = React.ComponentProps<typeof RNText> &
  VariantProps<typeof textVariants>

function Text({ className, variant = 'default', ...props }: TextProps) {
  return <RNText className={cn(textVariants({ variant }), className)} {...props} />
}

export { Text, textVariants }
