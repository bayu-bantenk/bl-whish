import * as React from 'react'
import { Image, Text, View } from 'react-native'

import { cn } from '@/utils'

function Avatar({ className, ...props }: React.ComponentProps<typeof View>) {
  return (
    <View
      className={cn(
        'h-10 w-10 items-center justify-center overflow-hidden rounded-full bg-muted',
        className
      )}
      {...props}
    />
  )
}

function AvatarImage({ className, ...props }: React.ComponentProps<typeof Image>) {
  return <Image className={cn('h-full w-full', className)} {...props} />
}

function AvatarFallback({ className, ...props }: React.ComponentProps<typeof Text>) {
  return (
    <Text
      className={cn('text-sm font-medium text-foreground', className)}
      {...props}
    />
  )
}

export { Avatar, AvatarFallback, AvatarImage }
