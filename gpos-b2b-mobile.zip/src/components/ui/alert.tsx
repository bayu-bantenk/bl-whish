import { cva, type VariantProps } from 'class-variance-authority'
import * as React from 'react'
import { Text, View } from 'react-native'

import { cn } from '@/utils'

// Dexain alerts: soft tinted body with a 4px accent rail on the left.
const alertVariants = cva('w-full rounded-md border border-l-4 p-4 gap-1', {
  variants: {
    variant: {
      default: 'border-border border-l-primary bg-card',
      destructive: 'border-destructive/30 border-l-destructive bg-destructive-soft',
      success: 'border-success/30 border-l-success bg-success-soft',
      warning: 'border-warning/30 border-l-warning bg-warning-soft',
      info: 'border-info/30 border-l-info bg-info-soft',
    },
  },
  defaultVariants: {
    variant: 'default',
  },
})

type AlertProps = React.ComponentProps<typeof View> &
  VariantProps<typeof alertVariants>

function Alert({ className, variant = 'default', ...props }: AlertProps) {
  return <View className={cn(alertVariants({ variant }), className)} {...props} />
}

function AlertTitle({ className, ...props }: React.ComponentProps<typeof Text>) {
  return (
    <Text
      className={cn('text-sm font-semibold text-foreground', className)}
      {...props}
    />
  )
}

function AlertDescription({
  className,
  ...props
}: React.ComponentProps<typeof Text>) {
  return (
    <Text className={cn('text-sm text-muted-foreground', className)} {...props} />
  )
}

export { Alert, AlertDescription, AlertTitle }
