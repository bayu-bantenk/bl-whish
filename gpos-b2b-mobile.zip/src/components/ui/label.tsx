import * as React from 'react'
import { Text } from 'react-native'

import { cn } from '@/utils'

type LabelProps = React.ComponentProps<typeof Text>

function Label({ className, ...props }: LabelProps) {
  return (
    <Text
      className={cn('text-sm font-medium text-foreground', className)}
      {...props}
    />
  )
}

export { Label }
