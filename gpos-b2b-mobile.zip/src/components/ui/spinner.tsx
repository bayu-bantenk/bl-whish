import * as React from 'react'
import { ActivityIndicator } from 'react-native'

import { useDexain } from '@/shared/styles'

type SpinnerProps = React.ComponentProps<typeof ActivityIndicator>

function Spinner({ size = 'small', color, ...props }: SpinnerProps) {
  const palette = useDexain()

  return <ActivityIndicator size={size} color={color ?? palette.brand} {...props} />
}

export { Spinner }
