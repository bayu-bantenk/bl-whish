import * as React from 'react'
import { TextInput } from 'react-native'

import { useDexain } from '@/shared/styles'
import { cn } from '@/utils'

type InputProps = React.ComponentProps<typeof TextInput>

const Input = React.forwardRef<TextInput, InputProps>(
  ({ className, placeholderTextColor, ...props }, ref) => {
    const palette = useDexain()

    return (
      <TextInput
        ref={ref}
        placeholderTextColor={placeholderTextColor ?? palette.fg4}
        className={cn(
          'h-10 w-full rounded-md border border-input bg-card px-3 py-2 text-base text-foreground',
          className
        )}
        {...props}
      />
    )
  }
)
Input.displayName = 'Input'

export { Input }
