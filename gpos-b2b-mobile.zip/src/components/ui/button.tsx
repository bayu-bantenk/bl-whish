import { cva, type VariantProps } from 'class-variance-authority'
import * as React from 'react'
import { Pressable } from 'react-native'

import { cn } from '@/utils'

const buttonVariants = cva(
  'flex-row shrink-0 items-center justify-center rounded-md gap-2',
  {
    variants: {
      variant: {
        default: 'bg-primary active:bg-primary-press',
        outline: 'border border-border bg-card active:bg-accent',
        ghost: 'bg-transparent active:bg-accent',
        destructive: 'bg-destructive active:opacity-90',
        secondary: 'bg-secondary active:bg-muted',
      },
      size: {
        sm: 'h-8 px-3',
        default: 'h-10 px-4',
        lg: 'h-12 px-6',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
)

type ButtonProps = React.ComponentProps<typeof Pressable> &
  VariantProps<typeof buttonVariants>

function Button({
  className,
  variant = 'default',
  size = 'default',
  disabled,
  ...props
}: ButtonProps) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      className={cn(
        buttonVariants({ variant, size }),
        disabled && 'opacity-50',
        className
      )}
      {...props}
    />
  )
}

export { Button, buttonVariants }
