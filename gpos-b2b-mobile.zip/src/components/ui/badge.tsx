import { cva, type VariantProps } from 'class-variance-authority'
import * as React from 'react'
import { Text, View } from 'react-native'

import { cn } from '@/utils'

const badgeVariants = cva(
  'self-start flex-row items-center rounded-full px-2.5 py-0.5',
  {
    variants: {
      variant: {
        default: 'bg-primary',
        secondary: 'bg-secondary',
        // Dexain chips are soft: tinted background + saturated text.
        destructive: 'bg-destructive-soft',
        success: 'bg-success-soft',
        warning: 'bg-warning-soft',
        info: 'bg-info-soft',
        outline: 'border border-border bg-transparent',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  }
)

const badgeTextVariants = cva('text-xs font-medium', {
  variants: {
    variant: {
      default: 'text-primary-foreground',
      secondary: 'text-secondary-foreground',
      destructive: 'text-destructive',
      success: 'text-success',
      warning: 'text-warning',
      info: 'text-info',
      outline: 'text-foreground',
    },
  },
  defaultVariants: {
    variant: 'default',
  },
})

type BadgeProps = React.ComponentProps<typeof View> &
  VariantProps<typeof badgeVariants> & {
    children?: React.ReactNode
  }

function Badge({ className, variant = 'default', children, ...props }: BadgeProps) {
  return (
    <View className={cn(badgeVariants({ variant }), className)} {...props}>
      {typeof children === 'string' ? (
        <Text className={badgeTextVariants({ variant })}>{children}</Text>
      ) : (
        children
      )}
    </View>
  )
}

export { Badge, badgeVariants }
