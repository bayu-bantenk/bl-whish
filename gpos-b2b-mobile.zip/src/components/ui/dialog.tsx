import * as React from 'react'
import { Modal, Pressable, Text, View } from 'react-native'

import { cn } from '@/utils'

type DialogContextValue = {
  open: boolean
  setOpen: (open: boolean) => void
}

const DialogContext = React.createContext<DialogContextValue | null>(null)

function useDialog() {
  const ctx = React.useContext(DialogContext)
  if (!ctx) {
    throw new Error('Dialog components must be used within <Dialog>')
  }
  return ctx
}

type DialogProps = {
  open?: boolean
  onOpenChange?: (open: boolean) => void
  children?: React.ReactNode
}

function Dialog({ open: openProp, onOpenChange, children }: DialogProps) {
  const [openState, setOpenState] = React.useState(false)
  const isControlled = openProp !== undefined
  const open = isControlled ? openProp : openState

  const setOpen = React.useCallback(
    (next: boolean) => {
      if (!isControlled) setOpenState(next)
      onOpenChange?.(next)
    },
    [isControlled, onOpenChange]
  )

  return (
    <DialogContext.Provider value={{ open, setOpen }}>
      {children}
    </DialogContext.Provider>
  )
}

type DialogTriggerProps = React.ComponentProps<typeof Pressable>

function DialogTrigger({ onPress, ...props }: DialogTriggerProps) {
  const { setOpen } = useDialog()
  return (
    <Pressable
      onPress={(e) => {
        onPress?.(e)
        setOpen(true)
      }}
      {...props}
    />
  )
}

type DialogContentProps = React.ComponentProps<typeof View>

function DialogContent({ className, children, ...props }: DialogContentProps) {
  const { open, setOpen } = useDialog()

  return (
    <Modal
      visible={open}
      transparent
      animationType="fade"
      onRequestClose={() => setOpen(false)}
    >
      <Pressable
        className="flex-1 items-center justify-center bg-black/50 px-6"
        onPress={() => setOpen(false)}
      >
        <Pressable
          onPress={(e) => e.stopPropagation()}
          className={cn(
            'w-full max-w-md rounded-xl border border-border bg-card p-5 gap-4',
            className
          )}
          {...props}
        >
          {children}
        </Pressable>
      </Pressable>
    </Modal>
  )
}

function DialogHeader({ className, ...props }: React.ComponentProps<typeof View>) {
  return <View className={cn('gap-1.5', className)} {...props} />
}

function DialogTitle({ className, ...props }: React.ComponentProps<typeof Text>) {
  return (
    <Text
      className={cn('text-lg font-semibold text-foreground', className)}
      {...props}
    />
  )
}

function DialogDescription({
  className,
  ...props
}: React.ComponentProps<typeof Text>) {
  return (
    <Text className={cn('text-sm text-muted-foreground', className)} {...props} />
  )
}

function DialogFooter({ className, ...props }: React.ComponentProps<typeof View>) {
  return (
    <View
      className={cn('flex-row items-center justify-end gap-2', className)}
      {...props}
    />
  )
}

export {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  useDialog,
}
