import { ChevronDown, type LucideIcon } from 'lucide-react-native'
import * as React from 'react'
import { Pressable } from 'react-native'

import { Text } from '@/components/ui/text'
import { useDexain } from '@/shared/styles'
import { cn } from '@/utils'

type SelectFieldProps = {
  /** Display text of the selected option; null/undefined shows the placeholder. */
  label?: string | null
  placeholder?: string
  icon?: LucideIcon
  error?: boolean
  disabled?: boolean
  onPress: () => void
  className?: string
}

/**
 * Dexain select trigger: an input-shaped field that opens a SelectSheet.
 * Pair with `<SelectSheet>` for the options list.
 */
function SelectField({
  label,
  placeholder = 'Pilih...',
  icon: Icon,
  error = false,
  disabled = false,
  onPress,
  className,
}: SelectFieldProps) {
  const palette = useDexain()

  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      className={cn(
        'h-10 flex-row items-center gap-2 rounded-md border border-input bg-card px-3 active:bg-accent',
        error && 'border-destructive',
        disabled && 'opacity-60',
        className
      )}
    >
      {Icon ? <Icon size={18} color={palette.fg4} /> : null}
      <Text
        className={cn(
          'flex-1 text-base',
          label ? 'text-foreground' : 'text-placeholder'
        )}
        numberOfLines={1}
      >
        {label || placeholder}
      </Text>
      <ChevronDown size={18} color={palette.fg3} />
    </Pressable>
  )
}

export { SelectField }
