import React, { useContext } from 'react'
import { View } from 'react-native'

import { Spinner } from '@/components/ui/spinner'
import { LoadingFullContext } from '@/shared/contexts'

export const Loading = () => {
  const { loadingFull } = useContext(LoadingFullContext)

  if (loadingFull === '0') return null

  return (
    <View className="absolute inset-0 z-50 items-center justify-center bg-black/40">
      <View className="items-center justify-center rounded-2xl bg-card p-6">
        <Spinner size="large" />
      </View>
    </View>
  )
}
