import { cva, type VariantProps } from 'class-variance-authority'
import * as React from 'react'
import { View } from 'react-native'

import { Text } from '@/components/ui/text'
import { cn } from '@/utils'

const statValueVariants = cva('text-2xl font-bold', {
  variants: {
    tone: {
      default: 'text-foreground',
      primary: 'text-primary',
      success: 'text-success',
      destructive: 'text-destructive',
      warning: 'text-warning',
      info: 'text-info',
    },
  },
  defaultVariants: {
    tone: 'default',
  },
})

type StatCardProps = React.ComponentProps<typeof View> &
  VariantProps<typeof statValueVariants> & {
    /** Small uppercase caption, e.g. "INVOICE". */
    label: string
    /** Big bold figure, e.g. "118". */
    value: string | number
  }

/**
 * Dexain stat card: uppercase caption over a large (optionally colored)
 * value. Render several in a `flex-row gap-2.5` for a summary strip.
 */
function StatCard({ label, value, tone, className, ...props }: StatCardProps) {
  return (
    <View
      className={cn(
        'flex-1 gap-1 rounded-lg border border-border bg-card p-3',
        className
      )}
      {...props}
    >
      <Text className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </Text>
      <Text className={statValueVariants({ tone })}>{String(value)}</Text>
    </View>
  )
}

export { StatCard }
