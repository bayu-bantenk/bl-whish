import type { LucideIcon } from 'lucide-react-native'
import * as React from 'react'
import { TextInput, View } from 'react-native'

import { PasswordInput } from '@/components/molecules/password-input/password-input'
import { Input } from '@/components/ui/input'
import { useDexain } from '@/shared/styles'
import { cn } from '@/utils'

type InputWithIconProps = React.ComponentProps<typeof TextInput> & {
  icon: LucideIcon
  /** Renders a PasswordInput (secure entry + visibility toggle) instead. */
  secure?: boolean
}

/**
 * Dexain form field: input with a leading icon inside the field
 * (e.g. Mail for email, Lock for password).
 */
const InputWithIcon = React.forwardRef<TextInput, InputWithIconProps>(
  ({ icon: Icon, secure = false, className, ...props }, ref) => {
    const palette = useDexain()
    const Field = secure ? PasswordInput : Input

    return (
      <View className="relative w-full">
        <View
          pointerEvents="none"
          className="absolute bottom-0 left-3 top-0 z-10 justify-center"
        >
          <Icon size={18} color={palette.fg4} />
        </View>
        <Field ref={ref} className={cn('pl-10', className)} {...props} />
      </View>
    )
  }
)
InputWithIcon.displayName = 'InputWithIcon'

export { InputWithIcon }
