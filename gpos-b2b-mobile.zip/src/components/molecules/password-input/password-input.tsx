import { Eye, EyeOff } from 'lucide-react-native'
import * as React from 'react'
import { forwardRef, useState } from 'react'
import { Pressable, TextInput, View } from 'react-native'

import { Input } from '@/components/ui/input'
import { useDexain } from '@/shared/styles'
import { cn } from '@/utils'

type PasswordInputProps = React.ComponentProps<typeof TextInput>

const PasswordInput = forwardRef<TextInput, PasswordInputProps>(
  ({ className, editable, ...props }, ref) => {
    const [showPassword, setShowPassword] = useState(false)
    const palette = useDexain()
    const disabled = editable === false

    return (
      <View className="relative w-full">
        <Input
          ref={ref}
          secureTextEntry={!showPassword}
          editable={editable}
          className={cn('pr-11', className)}
          {...props}
        />
        <Pressable
          accessibilityRole="button"
          disabled={disabled}
          onPress={() => setShowPassword((prev) => !prev)}
          className="absolute right-0 top-0 h-full items-center justify-center px-3"
        >
          {showPassword && !disabled ? (
            <Eye size={18} color={palette.fg2} />
          ) : (
            <EyeOff size={18} color={palette.fg2} />
          )}
        </Pressable>
      </View>
    )
  }
)
PasswordInput.displayName = 'PasswordInput'

export { PasswordInput }
