import type { VariantProps } from 'class-variance-authority'
import { ChevronRight, type LucideIcon } from 'lucide-react-native'
import * as React from 'react'
import { Pressable, View } from 'react-native'

import { Badge, badgeVariants } from '@/components/ui/badge'
import { Text } from '@/components/ui/text'
import { useDexain } from '@/shared/styles'
import { cn } from '@/utils'

export type ListItemTone =
  | 'default'
  | 'primary'
  | 'success'
  | 'destructive'
  | 'warning'
  | 'info'

const iconTileBg: Record<ListItemTone, string> = {
  default: 'bg-muted',
  primary: 'bg-accent',
  success: 'bg-success-soft',
  destructive: 'bg-destructive-soft',
  warning: 'bg-warning-soft',
  info: 'bg-info-soft',
}

const accentRail: Record<ListItemTone, string> = {
  default: 'border-l-border',
  primary: 'border-l-primary',
  success: 'border-l-success',
  destructive: 'border-l-destructive',
  warning: 'border-l-warning',
  info: 'border-l-info',
}

export type ListItemCardProps = {
  title: string
  subtitle?: string
  /** Bold right-aligned figure, e.g. an amount. */
  value?: string
  /** Small muted right-aligned caption, e.g. a date or "30 NET". */
  meta?: string
  /** Soft status chip under the value, e.g. { label: 'Berhasil', tone: 'success' }. */
  status?: {
    label: string
    tone?: VariantProps<typeof badgeVariants>['variant']
  }
  /** Leading icon in a soft circular tile. */
  icon?: LucideIcon
  iconTone?: ListItemTone
  /** Colored 4px rail on the left edge, like due-date cards. */
  accent?: ListItemTone
  chevron?: boolean
  onPress?: () => void
  onLongPress?: () => void
  className?: string
}

/**
 * Dexain list card: soft icon tile, bold title + muted subtitle, right
 * value/meta/status column. The standard row for every list screen.
 */
function ListItemCard({
  title,
  subtitle,
  value,
  meta,
  status,
  icon: Icon,
  iconTone = 'primary',
  accent,
  chevron = false,
  onPress,
  onLongPress,
  className,
}: ListItemCardProps) {
  const palette = useDexain()
  const interactive = Boolean(onPress || onLongPress)
  const iconColor: Record<ListItemTone, string> = {
    default: palette.fg2,
    primary: palette.brand,
    success: palette.success,
    destructive: palette.danger,
    warning: palette.warn,
    info: palette.info,
  }
  const tint = iconColor[iconTone]

  return (
    <Pressable
      accessibilityRole={interactive ? 'button' : undefined}
      disabled={!interactive}
      onPress={onPress}
      onLongPress={onLongPress}
      className={cn(
        'flex-row items-center gap-3 rounded-lg border border-border bg-card p-3.5',
        accent && `border-l-4 ${accentRail[accent]}`,
        interactive && 'active:bg-accent',
        className
      )}
    >
      {Icon ? (
        <View
          className={cn(
            'h-9 w-9 items-center justify-center rounded-full',
            iconTileBg[iconTone]
          )}
        >
          <Icon size={16} color={tint} />
        </View>
      ) : null}

      <View className="flex-1">
        <Text className="text-sm font-bold" numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? (
          <Text className="mt-0.5 text-xs text-muted-foreground" numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>

      {value || meta || status ? (
        <View className="items-end gap-1">
          {value ? <Text className="text-sm font-bold">{value}</Text> : null}
          {meta ? (
            <Text className="text-xs text-muted-foreground">{meta}</Text>
          ) : null}
          {status ? (
            <Badge variant={status.tone ?? 'secondary'}>{status.label}</Badge>
          ) : null}
        </View>
      ) : null}

      {chevron ? <ChevronRight size={18} color={palette.fg3} /> : null}
    </Pressable>
  )
}

export { ListItemCard }
