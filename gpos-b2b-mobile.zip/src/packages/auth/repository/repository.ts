import {
  Activation,
  Forgot,
  Login,
  Logout,
  RefreshToken,
  Register,
  Reset,
  ValidateSession,
} from '@/packages/auth/domain/auth'
import { RestAPI } from '@/shared/utils/rest-api'

export interface IRepository {
  login: (login: Login) => Promise<any>
  register: (register: Register) => Promise<any>
  forgot: (forgot: Forgot) => Promise<any>
  reset: (reset: Reset) => Promise<any>
  activation: (activation: Activation) => Promise<any>
  logout: (logout: Logout) => Promise<any>
  refreshToken: (refreshToken: RefreshToken) => Promise<any>
  validateSession: (validateSession: ValidateSession) => Promise<any>
}

export class Repository implements IRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async login(login: Login): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/login', {
        email: login.email,
        password: login.password,
        login_by: login.login_by,
      })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async register(register: Register): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/registration', {
        organization_name: register.organization_name,
        fullname: register.fullname,
        email: register.email,
        password: register.password,
      })

      if (response.code !== 201) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async forgot(forgot: Forgot): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/forget-password', {
        email: forgot.email,
      })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async reset(reset: Reset): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/reset-password', {
        forget_key: reset.forget_key,
        password: reset.password,
      })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async activation(activation: Activation): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/activation', {
        activation_key: activation.activation_key,
      })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async logout(logout: Logout): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/logout', {
        token: logout.token,
      })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async refreshToken(refreshToken: RefreshToken): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/refresh-token', {
        refresh_token: refreshToken.refresh_token,
      })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async validateSession(validateSession: ValidateSession): Promise<any> {
    try {
      const response: any = await this.api.post('/auth/validate-session', {
        entity: validateSession.entity,
        access: validateSession.access,
      })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }
}
