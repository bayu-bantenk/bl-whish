import axios, { AxiosInstance } from 'axios'
import { addDays, getUnixTime } from 'date-fns'
import Config from 'react-native-config'

import {
  Activation,
  Forgot,
  Login,
  Logout,
  RefreshToken,
  Register,
  Reset,
  ValidateSession,
} from '@/packages/auth/domain/auth'
import { Repository as AuthRepository } from '@/packages/auth/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'

export default function useAuthUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const authRepository = new AuthRepository(dataStoreApi)

  async function login(login: Login) {
    const response: any = await authRepository.login(login)

    if (response.code !== 200) {
      return response
    }

    const refreshExpiresIn = addDays(
      new Date(Number(response.data.data.expires_in) * 1000),
      3
    )

    return {
      ...response.data,
      data: {
        id: response.data.data.user_id,
        idx: response.data.data.user_idx,
        name: response.data.data.name,
        email: response.data.data.email,
        access_jwt: response.data.data.access_token,
        access_jwt_exp: Number(response.data.data.expires_in),
        refresh_jwt: response.data.data.refresh_token,
        refresh_jwt_exp: getUnixTime(refreshExpiresIn),
      },
    }
  }

  async function register(register: Register) {
    const response = await authRepository.register(register)
    return response
  }

  async function forgot(forgot: Forgot) {
    const response = await authRepository.forgot(forgot)
    return response
  }

  async function reset(reset: Reset) {
    const response = await authRepository.reset(reset)
    return response
  }

  async function activation(activation: Activation) {
    const response = await authRepository.activation(activation)
    return response
  }

  async function logout(logout: Logout) {
    const response = await authRepository.logout(logout)
    return response
  }

  async function refreshToken(refreshToken: RefreshToken) {
    const response: any = await authRepository.refreshToken(refreshToken)

    if (response.code !== 200) {
      return response
    }

    const refreshExpiresIn = addDays(
      new Date(Number(response.data.data.expires_in) * 1000),
      3
    )

    return {
      ...response.data,
      data: {
        access_jwt: response.data.data.access_token,
        access_jwt_exp: Number(response.data.data.expires_in),
        refresh_jwt: response.data.data.refresh_token,
        refresh_jwt_exp: getUnixTime(refreshExpiresIn),
      },
    }
  }

  async function validateSession(validateSession: ValidateSession) {
    const response = await authRepository.validateSession(validateSession)
    return response
  }

  return {
    login,
    register,
    forgot,
    reset,
    activation,
    logout,
    refreshToken,
    validateSession,
  }
}
