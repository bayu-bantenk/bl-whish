export type Login = {
  email: string
  password: string
  login_by: 'credentials' | 'dexan'
}

export type Register = {
  organization_name: string
  fullname: string
  email: string
  password: string
}

export type Forgot = {
  email: string
}

export type Reset = {
  forget_key: string
  password: string
}

export type Activation = {
  activation_key: string
}

export type Logout = {
  token: string
}

export type RefreshToken = {
  refresh_token: string
}

export type ValidateSession = {
  entity: string
  access: string
}
