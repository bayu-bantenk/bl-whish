import { useNavigation, useRoute } from '@react-navigation/native'
import { Lock, Mail } from 'lucide-react-native'
import React, { useEffect, useState } from 'react'
import { View } from 'react-native'

import { InputWithIcon } from '@/components/molecules/input-with-icon/input-with-icon'
import { ConfirmModal } from '@/components/organisms/modal/confirm-modal'
import { AuthLayout } from '@/components/templates/auth-layout'
import {
  Alert,
  AlertDescription,
  AlertTitle,
  Button,
  Label,
  Spinner,
  Text,
} from '@/components/ui'
import useAuthUseCase from '@/packages/auth/usecases/usecase'
import { authRoute } from '@/shared/constants'
import { useTranslation } from '@/shared/dictionaries'
import { dexain } from '@/shared/styles'
import { postLogin, useAuthSession } from '@/shared/utils/auth'

export default function LoginView() {
  const navigation = useNavigation<any>()
  const route = useRoute<any>()
  const activationKey: string = route.params?.activation_key ?? ''

  const { isAuthenticated } = useAuthSession()
  const { activation } = useAuthUseCase()
  const { t } = useTranslation()

  const [loading, setLoading] = useState(false)
  const [formValues, setFormValues] = useState({
    email: '',
    password: '',
  })
  const [error, setError] = useState('')
  const [incompleteOpen, setIncompleteOpen] = useState(false)

  useEffect(() => {
    async function onSubmitActivation() {
      setError('')

      if (activationKey) {
        const res = await activation({
          activation_key: activationKey,
        })

        if (res?.code !== 200) {
          setError(t.auth.login.activationExpired)
        }
      }
    }

    onSubmitActivation()
  }, [activationKey])

  const handleChange = (name: string, value: string) => {
    setFormValues((prev) => ({ ...prev, [name]: value }))
  }

  const onSubmit = async () => {
    setError('')

    if (!formValues.email.trim() || !formValues.password) {
      setIncompleteOpen(true)
      return
    }

    try {
      setLoading(true)

      const response = await postLogin({
        email: formValues.email,
        password: formValues.password,
        login_by: 'credentials',
      })

      if (response && 'success' in response && response.success) {
        // RootNavigator switches automatically when isAuthenticated flips
        return
      }

      setLoading(false)
      setError(t.auth.login.wrongCredentials)
    } catch {
      setLoading(false)
      setError(t.auth.login.loginFailed)
    }
  }

  useEffect(() => {
    if (isAuthenticated) {
      setLoading(false)
    }
  }, [isAuthenticated])

  return (
    <AuthLayout title={t.auth.login.title} description={t.auth.login.description}>
      <View className="gap-5">
        {error ? (
          <Alert variant="destructive">
            <AlertTitle>{t.common.oops}</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}

        <View className="gap-2">
          <Label nativeID="email" className="font-semibold">
            {t.auth.login.email}
          </Label>
          <InputWithIcon
            icon={Mail}
            placeholder="nama@aam.co.id"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            value={formValues.email}
            onChangeText={(value) => handleChange('email', value)}
            editable={!loading}
          />
        </View>

        <View className="gap-2">
          <Label nativeID="password" className="font-semibold">
            {t.auth.login.password}
          </Label>
          <InputWithIcon
            icon={Lock}
            secure
            placeholder="●●●●●●●●"
            value={formValues.password}
            onChangeText={(value: string) => handleChange('password', value)}
            editable={!loading}
          />
        </View>

        <Button size="lg" onPress={onSubmit} disabled={loading} className="w-full">
          {loading ? <Spinner className="mr-2" color={dexain.fgInvert} /> : null}
          <Text className="font-bold text-primary-foreground">
            {t.auth.login.submit}
          </Text>
        </Button>

        <Text
          className="text-center text-sm font-semibold text-primary"
          onPress={() => navigation.navigate(authRoute.forgot)}
        >
          {t.auth.login.forgot}
        </Text>

        <View className="flex-row items-center justify-center gap-1">
          <Text className="text-sm text-muted-foreground">
            {t.auth.login.noAccount}
          </Text>
          <Text
            className="text-sm font-semibold text-primary"
            onPress={() => navigation.navigate(authRoute.register)}
          >
            {t.auth.login.register}
          </Text>
        </View>
      </View>

      <ConfirmModal
        open={incompleteOpen}
        onOpenChange={setIncompleteOpen}
        tone="destructive"
        title={t.common.warning}
        description={t.auth.login.incompleteDescription}
        confirmText={t.common.ok}
      />
    </AuthLayout>
  )
}
