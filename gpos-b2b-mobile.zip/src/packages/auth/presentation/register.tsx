import { useNavigation } from '@react-navigation/native'
import { Building2, Lock, Mail, UserRound } from 'lucide-react-native'
import React, { useState } from 'react'
import { View } from 'react-native'

import { InputWithIcon } from '@/components/molecules/input-with-icon/input-with-icon'
import { AuthLayout } from '@/components/templates/auth-layout'
import {
  Alert,
  AlertDescription,
  AlertTitle,
  Button,
  Label,
  Spinner,
  Text,
} from '@/components/ui'
import useAuthUseCase from '@/packages/auth/usecases/usecase'
import { authRoute } from '@/shared/constants'
import { useTranslation } from '@/shared/dictionaries'
import { dexain } from '@/shared/styles'

export default function RegisterView() {
  const navigation = useNavigation<any>()
  const { register } = useAuthUseCase()
  const { t } = useTranslation()

  const [loading, setLoading] = useState(false)
  const [formValues, setFormValues] = useState({
    organization_name: '',
    fullname: '',
    email: '',
    password: '',
    confirm: '',
  })
  const [error, setError] = useState('')

  const handleChange = (name: string, value: string) => {
    setFormValues((prev) => ({ ...prev, [name]: value }))
  }

  const onSubmit = async () => {
    setError('')

    if (formValues.password !== formValues.confirm) {
      setError(t.auth.register.passwordMismatch)
      return
    }

    try {
      setLoading(true)

      const res = await register({
        organization_name: formValues.organization_name,
        fullname: formValues.fullname,
        email: formValues.email,
        password: formValues.password,
      })

      setLoading(false)

      if (res.code === 200 || res.code === 201) {
        navigation.navigate(authRoute.login)
      } else {
        setError(t.auth.register.registerFailed)
      }
    } catch {
      setLoading(false)
      setError(t.auth.register.registerError)
    }
  }

  return (
    <AuthLayout
      title={t.auth.register.title}
      description={t.auth.register.description}
    >
      <View className="gap-5">
        {error ? (
          <Alert variant="destructive">
            <AlertTitle>{t.common.oops}</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}

        <View className="gap-2">
          <Label nativeID="organization_name" className="font-semibold">
            {t.auth.register.organizationName}
          </Label>
          <InputWithIcon
            icon={Building2}
            placeholder={t.auth.register.organizationPlaceholder}
            autoCapitalize="none"
            autoCorrect={false}
            value={formValues.organization_name}
            onChangeText={(value) => handleChange('organization_name', value)}
            editable={!loading}
          />
        </View>

        <View className="gap-2">
          <Label nativeID="fullname" className="font-semibold">
            {t.auth.register.fullname}
          </Label>
          <InputWithIcon
            icon={UserRound}
            placeholder={t.auth.register.fullnamePlaceholder}
            autoCorrect={false}
            value={formValues.fullname}
            onChangeText={(value) => handleChange('fullname', value)}
            editable={!loading}
          />
        </View>

        <View className="gap-2">
          <Label nativeID="email" className="font-semibold">
            {t.auth.register.email}
          </Label>
          <InputWithIcon
            icon={Mail}
            placeholder="nama@aam.co.id"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            value={formValues.email}
            onChangeText={(value) => handleChange('email', value)}
            editable={!loading}
          />
        </View>

        <View className="gap-2">
          <Label nativeID="password" className="font-semibold">
            {t.auth.register.password}
          </Label>
          <InputWithIcon
            icon={Lock}
            secure
            placeholder="●●●●●●●●"
            value={formValues.password}
            onChangeText={(value: string) => handleChange('password', value)}
            editable={!loading}
          />
        </View>

        <View className="gap-2">
          <Label nativeID="confirm" className="font-semibold">
            {t.auth.register.confirmPassword}
          </Label>
          <InputWithIcon
            icon={Lock}
            secure
            placeholder="●●●●●●●●"
            value={formValues.confirm}
            onChangeText={(value: string) => handleChange('confirm', value)}
            editable={!loading}
          />
        </View>

        <Button size="lg" onPress={onSubmit} disabled={loading} className="w-full">
          {loading ? <Spinner className="mr-2" color={dexain.fgInvert} /> : null}
          <Text className="font-bold text-primary-foreground">
            {t.auth.register.submit}
          </Text>
        </Button>

        <View className="flex-row items-center justify-center gap-1">
          <Text className="text-sm text-muted-foreground">
            {t.auth.register.hasAccount}
          </Text>
          <Text
            className="text-sm font-semibold text-primary"
            onPress={() => navigation.navigate(authRoute.login)}
          >
            {t.auth.register.login}
          </Text>
        </View>
      </View>
    </AuthLayout>
  )
}
