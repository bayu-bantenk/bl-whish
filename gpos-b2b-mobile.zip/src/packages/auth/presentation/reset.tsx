import { useNavigation, useRoute } from '@react-navigation/native'
import { Lock } from 'lucide-react-native'
import React, { useState } from 'react'
import { View } from 'react-native'

import { InputWithIcon } from '@/components/molecules/input-with-icon/input-with-icon'
import { AuthLayout } from '@/components/templates/auth-layout'
import {
  Alert,
  AlertDescription,
  AlertTitle,
  Button,
  Label,
  Spinner,
  Text,
} from '@/components/ui'
import useAuthUseCase from '@/packages/auth/usecases/usecase'
import { authRoute } from '@/shared/constants'
import { useTranslation } from '@/shared/dictionaries'
import { dexain } from '@/shared/styles'

export default function ResetView() {
  const navigation = useNavigation<any>()
  const route = useRoute<any>()
  const forgetKey: string = route.params?.forget_key ?? ''

  const { reset } = useAuthUseCase()
  const { t } = useTranslation()

  const [loading, setLoading] = useState(false)
  const [formValues, setFormValues] = useState({
    password: '',
    confirm: '',
  })
  const [error, setError] = useState('')

  const handleChange = (name: string, value: string) => {
    setFormValues((prev) => ({ ...prev, [name]: value }))
  }

  const onSubmit = async () => {
    setError('')

    if (formValues.password !== formValues.confirm) {
      setError(t.auth.reset.passwordMismatch)
      return
    }

    try {
      setLoading(true)

      const res = await reset({
        forget_key: forgetKey,
        password: formValues.password,
      })

      setLoading(false)

      if (res.code === 200) {
        navigation.navigate(authRoute.login)
      } else {
        setError(t.auth.reset.resetFailed)
      }
    } catch {
      setLoading(false)
      setError(t.common.errorGeneric)
    }
  }

  return (
    <AuthLayout title={t.auth.reset.title} description={t.auth.reset.description}>
      <View className="gap-5">
        {error ? (
          <Alert variant="destructive">
            <AlertTitle>{t.common.oops}</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}

        <View className="gap-2">
          <Label nativeID="password" className="font-semibold">
            {t.auth.reset.newPassword}
          </Label>
          <InputWithIcon
            icon={Lock}
            secure
            placeholder="●●●●●●●●"
            value={formValues.password}
            onChangeText={(value: string) => handleChange('password', value)}
            editable={!loading}
          />
        </View>

        <View className="gap-2">
          <Label nativeID="confirm" className="font-semibold">
            {t.auth.reset.confirmPassword}
          </Label>
          <InputWithIcon
            icon={Lock}
            secure
            placeholder="●●●●●●●●"
            value={formValues.confirm}
            onChangeText={(value: string) => handleChange('confirm', value)}
            editable={!loading}
          />
        </View>

        <Button size="lg" onPress={onSubmit} disabled={loading} className="w-full">
          {loading ? <Spinner className="mr-2" color={dexain.fgInvert} /> : null}
          <Text className="font-bold text-primary-foreground">
            {t.auth.reset.submit}
          </Text>
        </Button>

        <Text
          className="text-center text-sm font-semibold text-primary"
          onPress={() => navigation.navigate(authRoute.login)}
        >
          {t.auth.reset.backToLogin}
        </Text>
      </View>
    </AuthLayout>
  )
}
