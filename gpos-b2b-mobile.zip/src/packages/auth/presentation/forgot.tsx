import { useNavigation } from '@react-navigation/native'
import { Mail } from 'lucide-react-native'
import React, { useState } from 'react'
import { View } from 'react-native'

import { InputWithIcon } from '@/components/molecules/input-with-icon/input-with-icon'
import { AuthLayout } from '@/components/templates/auth-layout'
import {
  Alert,
  AlertDescription,
  AlertTitle,
  Button,
  Label,
  Spinner,
  Text,
} from '@/components/ui'
import useAuthUseCase from '@/packages/auth/usecases/usecase'
import { authRoute } from '@/shared/constants'
import { useTranslation } from '@/shared/dictionaries'
import { dexain } from '@/shared/styles'

export default function ForgotView() {
  const navigation = useNavigation<any>()
  const { forgot } = useAuthUseCase()
  const { t } = useTranslation()

  const [loading, setLoading] = useState(false)
  const [formValues, setFormValues] = useState({
    email: '',
  })
  const [error, setError] = useState('')

  const handleChange = (name: string, value: string) => {
    setFormValues((prev) => ({ ...prev, [name]: value }))
  }

  const onSubmit = async () => {
    setError('')

    try {
      setLoading(true)

      const res = await forgot({
        email: formValues.email,
      })

      setLoading(false)

      if (res.code === 200) {
        navigation.navigate(authRoute.login)
      } else {
        setError(res.message)
      }
    } catch {
      setLoading(false)
      setError(t.common.errorGeneric)
    }
  }

  return (
    <AuthLayout title={t.auth.forgot.title} description={t.auth.forgot.description}>
      <View className="gap-5">
        {error ? (
          <Alert variant="destructive">
            <AlertTitle>{t.common.oops}</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}

        <View className="gap-2">
          <Label nativeID="email" className="font-semibold">
            {t.auth.forgot.email}
          </Label>
          <InputWithIcon
            icon={Mail}
            placeholder="nama@aam.co.id"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            value={formValues.email}
            onChangeText={(value) => handleChange('email', value)}
            editable={!loading}
          />
        </View>

        <Button size="lg" onPress={onSubmit} disabled={loading} className="w-full">
          {loading ? <Spinner className="mr-2" color={dexain.fgInvert} /> : null}
          <Text className="font-bold text-primary-foreground">
            {t.auth.forgot.submit}
          </Text>
        </Button>

        <Text
          className="text-center text-sm font-semibold text-primary"
          onPress={() => navigation.navigate(authRoute.login)}
        >
          {t.auth.forgot.backToLogin}
        </Text>
      </View>
    </AuthLayout>
  )
}
