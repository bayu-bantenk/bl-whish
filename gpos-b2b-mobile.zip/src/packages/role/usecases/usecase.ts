import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import { RoleCreate, RoleUpdate } from '@/packages/role/domain/role'
import { Repository as RoleRepository } from '@/packages/role/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function useRoleUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const roleRepository = new RoleRepository(dataStoreApi)

  async function getAllRole(searchParams: IndexPageProps) {
    const response = await roleRepository.getAllRole(searchParams)

    if (response.code !== 200) {
      return {
        docs: [],
        limit: 10,
        page: 1,
        pages: 0,
        total: 0,
      }
    }

    return {
      docs: response.data.data.docs,
      limit: response.data.data.limit,
      page: response.data.data.page,
      pages: response.data.data.pages,
      total: response.data.data.total,
    }
  }

  async function getSelectRole(searchParams: IndexPageProps) {
    const response = await roleRepository.getSelectRole(searchParams)
    return response
  }

  async function getOneRole(id: string) {
    const response = await roleRepository.getOneRole(id)
    return response
  }

  async function createRole(data: RoleCreate) {
    const response = await roleRepository.createRole(data)
    return response
  }

  async function updateRole(data: RoleUpdate) {
    const response = await roleRepository.updateRole(data)
    return response
  }

  async function deleteRole(id: string) {
    const response = await roleRepository.deleteRole(id)
    return response
  }

  return {
    getAllRole,
    getSelectRole,
    getOneRole,
    createRole,
    updateRole,
    deleteRole,
  }
}
