import { RoleCreate, RoleUpdate } from '@/packages/role/domain/role'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IRoleRepository {
  getAllRole: (params: IndexPageProps) => Promise<any>
  getSelectRole: (params: IndexPageProps) => Promise<any>
  getOneRole: (id: string) => Promise<any>
  createRole: (data: RoleCreate) => Promise<any>
  updateRole: (data: RoleUpdate) => Promise<any>
  deleteRole: (id: string) => Promise<any>
}

export class Repository implements IRoleRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getAllRole(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/roles', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getSelectRole(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/roles/select', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getOneRole(id: string): Promise<any> {
    try {
      const response: any = await this.api.get(`/roles/${id}`)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async createRole(data: RoleCreate): Promise<any> {
    try {
      const response: any = await this.api.post('/roles', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async updateRole(data: RoleUpdate): Promise<any> {
    try {
      const response: any = await this.api.put('/roles', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async deleteRole(id: string): Promise<any> {
    try {
      const response: any = await this.api.delete('/roles', { id: id })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          status: 'error',
        }
      }

      return {
        code: response.code,
        message: response.message,
        status: 'success',
      }
    } catch (error) {
      return {
        code: 500,
        message: error,
        status: 'error',
      }
    }
  }
}
