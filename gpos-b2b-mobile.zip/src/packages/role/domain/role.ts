export type Role = {
  id: number
  idx: string
  title: string
  slug: string
  description: string
  /** '1' = active */
  status: string
  permission_set_id: number
  created_by: number
  updated_by: number
  created_at: string
  updated_at: string
}

export type RoleTable = {
  docs: Role[]
  limit: number
  page: number
  pages: number
  total: number
}

export type RoleCreate = {
  title: string
  description: string
  status?: string
}

export type RoleUpdate = {
  id: string
  title: string
  description: string
  status?: string
}
