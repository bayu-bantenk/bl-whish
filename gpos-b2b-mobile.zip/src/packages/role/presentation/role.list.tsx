import { useFocusEffect } from '@react-navigation/native'
import { format } from 'date-fns'
import { LifeBuoy } from 'lucide-react-native'
import React, { useCallback, useState } from 'react'
import { View } from 'react-native'

import { CardList } from '@/components/organisms/card-list'
import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import type { Role } from '@/packages/role/domain/role'
import useRoleUseCase from '@/packages/role/usecases/usecase'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'

const fmtDate = (value: string) => {
  const date = new Date(value)
  return isNaN(+date) ? undefined : format(date, 'dd MMM yyyy')
}

export default function RoleListView() {
  const { token } = useAuthSession()
  const { getAllRole } = useRoleUseCase(token)
  const { t } = useTranslation()

  const [roles, setRoles] = useState<Role[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    if (!token) return

    setLoading(true)
    const params: IndexPageProps = { searchParams: {} }
    const data = await getAllRole(params)
    setRoles(data.docs ?? [])
    setLoading(false)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  return (
    <DashboardLayout>
      <Header title={t.role.title} />
      <View className="flex-1 px-4 py-3">
        <CardList<Role>
          data={roles}
          keyExtractor={(row) => row.idx}
          header={t.role.listHeader}
          headerRight={translate(t.role.countLabel, { count: roles.length })}
          refreshing={loading}
          onRefresh={load}
          emptyMessage={t.role.empty}
          item={(row) => ({
            icon: LifeBuoy,
            iconTone: row.status === '1' ? 'primary' : 'default',
            title: row.title,
            subtitle: `${row.slug} · ${row.description}`,
            meta: fmtDate(row.created_at),
            status:
              row.status === '1'
                ? { label: t.role.active, tone: 'success' }
                : { label: t.role.inactive, tone: 'secondary' },
          })}
        />
      </View>
    </DashboardLayout>
  )
}
