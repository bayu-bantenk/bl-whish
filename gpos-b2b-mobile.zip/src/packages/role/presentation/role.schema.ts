import { z } from 'zod'

export const roleTableSchema = z.object({
  id: z.number(),
  idx: z.string(),
  title: z.string(),
  slug: z.string(),
  description: z.string(),
  status: z.string(),
  permission_set_id: z.number(),
  created_at: z.string(),
})

export type RoleScheme = z.infer<typeof roleTableSchema>

export const roleFormSchema = z.object({
  title: z
    .string()
    .min(3, {
      message: 'Title must be at least 3 characters.',
    })
    .max(50, {
      message: 'Title must not be longer than 50 characters.',
    }),
  description: z
    .string()
    .max(255, {
      message: 'Description must not be longer than 255 characters.',
    })
    .optional(),
})

export type RoleFormSchema = z.infer<typeof roleFormSchema>
