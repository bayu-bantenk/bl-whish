export type AuditLog = {
  id: number
  idx: string
  action: string
  entity: string
  user: string
  created_at: string
}

export type AuditLogTable = {
  docs: AuditLog[]
  limit: number
  page: number
  pages: number
  total: number
}
