import { useFocusEffect } from '@react-navigation/native'
import { format } from 'date-fns'
import { FileClock } from 'lucide-react-native'
import React, { useCallback, useState } from 'react'
import { View } from 'react-native'

import { CardList } from '@/components/organisms/card-list'
import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import type { AuditLog } from '@/packages/audit-log/domain/audit-log'
import useAuditLogUseCase from '@/packages/audit-log/usecases/usecase'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'

const fmtDate = (value: string) => {
  const date = new Date(value)
  return isNaN(+date) ? undefined : format(date, 'dd MMM yyyy')
}

export default function AuditLogListView() {
  const { token } = useAuthSession()
  const { getAllAuditLog } = useAuditLogUseCase(token)
  const { t } = useTranslation()

  const [items, setItems] = useState<AuditLog[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    if (!token) return

    setLoading(true)
    const params: IndexPageProps = { searchParams: {} }
    const data = await getAllAuditLog(params)
    setItems(data.docs ?? [])
    setLoading(false)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  return (
    <DashboardLayout>
      <Header title={t.auditLog.title} />
      <View className="flex-1 px-4 py-3">
        <CardList<AuditLog>
          data={items}
          keyExtractor={(row) => row.idx}
          header={t.auditLog.listHeader}
          headerRight={translate(t.auditLog.countLabel, { count: items.length })}
          refreshing={loading}
          onRefresh={load}
          emptyMessage={t.auditLog.empty}
          item={(row) => ({
            icon: FileClock,
            iconTone: 'info',
            title: row.action,
            subtitle: `${row.entity} · ${row.user}`,
            meta: fmtDate(row.created_at),
          })}
        />
      </View>
    </DashboardLayout>
  )
}
