import { z } from 'zod'

export const auditLogTableSchema = z.object({
  id: z.number(),
  idx: z.string(),
  action: z.string(),
  entity: z.string(),
  user: z.string(),
  created_at: z.string(),
})

export type AuditLogScheme = z.infer<typeof auditLogTableSchema>
