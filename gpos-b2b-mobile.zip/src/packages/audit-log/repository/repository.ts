import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IAuditLogRepository {
  getAllAuditLog: (params: IndexPageProps) => Promise<any>
  getOneAuditLog: (id: string) => Promise<any>
}

export class Repository implements IAuditLogRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getAllAuditLog(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/audit-logs', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getOneAuditLog(id: string): Promise<any> {
    try {
      const response: any = await this.api.get(`/audit-logs/${id}`)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }
}
