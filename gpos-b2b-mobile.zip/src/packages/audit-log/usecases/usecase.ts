import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import { Repository as AuditLogRepository } from '@/packages/audit-log/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function useAuditLogUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const auditLogRepository = new AuditLogRepository(dataStoreApi)

  async function getAllAuditLog(searchParams: IndexPageProps) {
    const response = await auditLogRepository.getAllAuditLog(searchParams)

    if (response.code !== 200) {
      return {
        docs: [],
        limit: 10,
        page: 1,
        pages: 0,
        total: 0,
      }
    }

    return {
      docs: response.data.data.docs,
      limit: response.data.data.limit,
      page: response.data.data.page,
      pages: response.data.data.pages,
      total: response.data.data.total,
    }
  }

  async function getOneAuditLog(id: string) {
    const response = await auditLogRepository.getOneAuditLog(id)
    return response
  }

  return {
    getAllAuditLog,
    getOneAuditLog,
  }
}
