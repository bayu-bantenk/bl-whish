export type DashboardSummary = {
  total_users: number
  total_roles: number
  total_permission_sets: number
  total_api_keys: number
  total_workflows: number
  total_audit_logs: number
}
