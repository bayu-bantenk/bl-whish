import { useFocusEffect } from '@react-navigation/native'
import React, { useCallback, useState } from 'react'
import { ScrollView, View } from 'react-native'

import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import { Card, CardContent, Text } from '@/components/ui'
import type { DashboardSummary } from '@/packages/dashboard/domain/dashboard'
import useDashboardUseCase from '@/packages/dashboard/usecases/usecase'
import { type Dictionary, useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'

const cards: {
  key: keyof DashboardSummary
  labelKey: keyof Dictionary['dashboard']['cards']
}[] = [
  { key: 'total_users', labelKey: 'users' },
  { key: 'total_roles', labelKey: 'roles' },
  { key: 'total_permission_sets', labelKey: 'permissionSets' },
  { key: 'total_api_keys', labelKey: 'apiKeys' },
  { key: 'total_workflows', labelKey: 'workflows' },
  { key: 'total_audit_logs', labelKey: 'auditLogs' },
]

export default function DashboardListView() {
  const { token } = useAuthSession()
  const { getSummary } = useDashboardUseCase(token)
  const { t } = useTranslation()

  const [summary, setSummary] = useState<DashboardSummary | null>(null)

  const load = useCallback(async () => {
    if (!token) return

    const params: IndexPageProps = { searchParams: {} }
    const data = await getSummary(params)
    setSummary(data)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  return (
    <DashboardLayout>
      <Header title={t.dashboard.title} />
      <ScrollView contentContainerClassName="p-4">
        <View className="flex-row flex-wrap gap-4">
          {cards.map((card) => (
            <Card key={card.key} className="min-w-[45%] flex-1">
              <CardContent className="gap-1 py-4">
                <Text className="text-sm text-muted-foreground">
                  {t.dashboard.cards[card.labelKey]}
                </Text>
                <Text className="text-3xl font-bold">
                  {summary ? summary[card.key] : 0}
                </Text>
              </CardContent>
            </Card>
          ))}
        </View>
      </ScrollView>
    </DashboardLayout>
  )
}
