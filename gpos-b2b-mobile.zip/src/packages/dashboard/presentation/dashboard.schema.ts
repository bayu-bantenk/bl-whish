import { z } from 'zod'

export const dashboardSummarySchema = z.object({
  total_users: z.number(),
  total_roles: z.number(),
  total_permission_sets: z.number(),
  total_api_keys: z.number(),
  total_workflows: z.number(),
  total_audit_logs: z.number(),
})

export type DashboardSummaryScheme = z.infer<typeof dashboardSummarySchema>
