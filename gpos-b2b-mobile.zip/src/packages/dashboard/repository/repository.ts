import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IDashboardRepository {
  getSummary: (params: IndexPageProps) => Promise<any>
}

export class Repository implements IDashboardRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getSummary(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get(
        '/dashboard/summary',
        params.searchParams
      )

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }
}
