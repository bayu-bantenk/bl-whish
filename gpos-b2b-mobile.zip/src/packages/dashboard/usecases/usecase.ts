import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import { DashboardSummary } from '@/packages/dashboard/domain/dashboard'
import { Repository as DashboardRepository } from '@/packages/dashboard/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function useDashboardUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const dashboardRepository = new DashboardRepository(dataStoreApi)

  async function getSummary(
    searchParams: IndexPageProps
  ): Promise<DashboardSummary> {
    const response = await dashboardRepository.getSummary(searchParams)

    if (response.code !== 200) {
      return {
        total_users: 0,
        total_roles: 0,
        total_permission_sets: 0,
        total_api_keys: 0,
        total_workflows: 0,
        total_audit_logs: 0,
      }
    }

    return response.data.data as DashboardSummary
  }

  return {
    getSummary,
  }
}
