import {
  AttributeCreate,
  AttributeUpdate,
} from '@/packages/attribute/domain/attribute'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IAttributeRepository {
  getAllAttribute: (params: IndexPageProps) => Promise<any>
  getOneAttribute: (id: string) => Promise<any>
  createAttribute: (data: AttributeCreate) => Promise<any>
  updateAttribute: (data: AttributeUpdate) => Promise<any>
  deleteAttribute: (id: string) => Promise<any>
}

export class Repository implements IAttributeRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getAllAttribute(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/attributes', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getOneAttribute(id: string): Promise<any> {
    try {
      const response: any = await this.api.get(`/attributes/${id}`)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async createAttribute(data: AttributeCreate): Promise<any> {
    try {
      const response: any = await this.api.post('/attributes', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async updateAttribute(data: AttributeUpdate): Promise<any> {
    try {
      const response: any = await this.api.put('/attributes', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async deleteAttribute(id: string): Promise<any> {
    try {
      const response: any = await this.api.delete('/attributes', { id: id })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          status: 'error',
        }
      }

      return {
        code: response.code,
        message: response.message,
        status: 'success',
      }
    } catch (error) {
      return {
        code: 500,
        message: error,
        status: 'error',
      }
    }
  }
}
