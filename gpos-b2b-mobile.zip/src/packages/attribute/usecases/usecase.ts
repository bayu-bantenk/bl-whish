import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import {
  AttributeCreate,
  AttributeUpdate,
} from '@/packages/attribute/domain/attribute'
import { Repository as AttributeRepository } from '@/packages/attribute/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function useAttributeUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const attributeRepository = new AttributeRepository(dataStoreApi)

  async function getAllAttribute(searchParams: IndexPageProps) {
    const response = await attributeRepository.getAllAttribute(searchParams)

    if (response.code !== 200) {
      return {
        docs: [],
        limit: 10,
        page: 1,
        pages: 0,
        total: 0,
      }
    }

    return {
      docs: response.data.data.docs,
      limit: response.data.data.limit,
      page: response.data.data.page,
      pages: response.data.data.pages,
      total: response.data.data.total,
    }
  }

  async function getOneAttribute(id: string) {
    const response = await attributeRepository.getOneAttribute(id)
    return response
  }

  async function createAttribute(data: AttributeCreate) {
    const response = await attributeRepository.createAttribute(data)
    return response
  }

  async function updateAttribute(data: AttributeUpdate) {
    const response = await attributeRepository.updateAttribute(data)
    return response
  }

  async function deleteAttribute(id: string) {
    const response = await attributeRepository.deleteAttribute(id)
    return response
  }

  return {
    getAllAttribute,
    getOneAttribute,
    createAttribute,
    updateAttribute,
    deleteAttribute,
  }
}
