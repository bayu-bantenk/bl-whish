export type Attribute = {
  id: number
  idx: string
  name: string
  type: string
  created_at: string
  updated_at: string
}

export type AttributeTable = {
  docs: Attribute[]
  limit: number
  page: number
  pages: number
  total: number
}

export type AttributeCreate = {
  name: string
  type: string
}

export type AttributeUpdate = {
  id: string
  name: string
  type: string
}
