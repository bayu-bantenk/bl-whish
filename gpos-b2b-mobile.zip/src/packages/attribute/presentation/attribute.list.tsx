import { useFocusEffect } from '@react-navigation/native'
import { ListTodo } from 'lucide-react-native'
import React, { useCallback, useState } from 'react'
import { View } from 'react-native'

import { CardList } from '@/components/organisms/card-list'
import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import type { Attribute } from '@/packages/attribute/domain/attribute'
import useAttributeUseCase from '@/packages/attribute/usecases/usecase'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'

export default function AttributeListView() {
  const { token } = useAuthSession()
  const { getAllAttribute } = useAttributeUseCase(token)
  const { t } = useTranslation()

  const [items, setItems] = useState<Attribute[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    if (!token) return

    setLoading(true)
    const params: IndexPageProps = { searchParams: {} }
    const data = await getAllAttribute(params)
    setItems(data.docs ?? [])
    setLoading(false)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  return (
    <DashboardLayout>
      <Header title={t.attribute.title} />
      <View className="flex-1 px-4 py-3">
        <CardList<Attribute>
          data={items}
          keyExtractor={(row) => row.idx}
          header={t.attribute.listHeader}
          headerRight={translate(t.attribute.countLabel, { count: items.length })}
          refreshing={loading}
          onRefresh={load}
          emptyMessage={t.attribute.empty}
          item={(row) => ({
            icon: ListTodo,
            iconTone: 'primary',
            title: row.name,
            subtitle: row.type,
          })}
        />
      </View>
    </DashboardLayout>
  )
}
