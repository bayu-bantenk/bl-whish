import { z } from 'zod'

export const attributeTableSchema = z.object({
  id: z.number(),
  idx: z.string(),
  name: z.string(),
  type: z.string(),
  created_at: z.string(),
})

export type AttributeScheme = z.infer<typeof attributeTableSchema>

export const attributeFormSchema = z.object({
  name: z
    .string()
    .min(3, {
      message: 'Name must be at least 3 characters.',
    })
    .max(50, {
      message: 'Name must not be longer than 50 characters.',
    }),
  type: z.string().min(1, {
    message: 'Please select a type.',
  }),
})

export type AttributeFormSchema = z.infer<typeof attributeFormSchema>
