import { ApiKeyCreate, ApiKeyUpdate } from '@/packages/api-key/domain/api-key'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IApiKeyRepository {
  getAllApiKey: (params: IndexPageProps) => Promise<any>
  getOneApiKey: (id: string) => Promise<any>
  createApiKey: (data: ApiKeyCreate) => Promise<any>
  updateApiKey: (data: ApiKeyUpdate) => Promise<any>
  deleteApiKey: (id: string) => Promise<any>
}

export class Repository implements IApiKeyRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getAllApiKey(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/api-keys', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getOneApiKey(id: string): Promise<any> {
    try {
      const response: any = await this.api.get(`/api-keys/${id}`)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async createApiKey(data: ApiKeyCreate): Promise<any> {
    try {
      const response: any = await this.api.post('/api-keys', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async updateApiKey(data: ApiKeyUpdate): Promise<any> {
    try {
      const response: any = await this.api.put('/api-keys', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async deleteApiKey(id: string): Promise<any> {
    try {
      const response: any = await this.api.delete('/api-keys', { id: id })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          status: 'error',
        }
      }

      return {
        code: response.code,
        message: response.message,
        status: 'success',
      }
    } catch (error) {
      return {
        code: 500,
        message: error,
        status: 'error',
      }
    }
  }
}
