export type ApiKey = {
  id: number
  idx: string
  name: string
  key: string
  expired_at: string
  created_at: string
  updated_at: string
}

export type ApiKeyTable = {
  docs: ApiKey[]
  limit: number
  page: number
  pages: number
  total: number
}

export type ApiKeyCreate = {
  name: string
  expired_at: string
}

export type ApiKeyUpdate = {
  id: string
  name: string
  expired_at: string
}
