import { z } from 'zod'

export const apiKeyTableSchema = z.object({
  id: z.number(),
  idx: z.string(),
  name: z.string(),
  key: z.string(),
  expired_at: z.string(),
  created_at: z.string(),
})

export type ApiKeyScheme = z.infer<typeof apiKeyTableSchema>

export const apiKeyFormSchema = z.object({
  name: z
    .string()
    .min(3, {
      message: 'Name must be at least 3 characters.',
    })
    .max(50, {
      message: 'Name must not be longer than 50 characters.',
    }),
  expired_at: z.string().min(1, {
    message: 'Please provide an expiry date.',
  }),
})

export type ApiKeyFormSchema = z.infer<typeof apiKeyFormSchema>
