import { useFocusEffect } from '@react-navigation/native'
import { format } from 'date-fns'
import { KeySquare } from 'lucide-react-native'
import React, { useCallback, useState } from 'react'
import { View } from 'react-native'

import { CardList } from '@/components/organisms/card-list'
import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import type { ApiKey } from '@/packages/api-key/domain/api-key'
import useApiKeyUseCase from '@/packages/api-key/usecases/usecase'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'

const fmtDate = (value: string) => {
  const date = new Date(value)
  return isNaN(+date) ? undefined : format(date, 'dd MMM yyyy')
}

const isExpired = (value: string) => {
  const date = new Date(value)
  return !isNaN(+date) && date < new Date()
}

export default function ApiKeyListView() {
  const { token } = useAuthSession()
  const { getAllApiKey } = useApiKeyUseCase(token)
  const { t } = useTranslation()

  const [items, setItems] = useState<ApiKey[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    if (!token) return

    setLoading(true)
    const params: IndexPageProps = { searchParams: {} }
    const data = await getAllApiKey(params)
    setItems(data.docs ?? [])
    setLoading(false)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  return (
    <DashboardLayout>
      <Header title={t.apiKey.title} />
      <View className="flex-1 px-4 py-3">
        <CardList<ApiKey>
          data={items}
          keyExtractor={(row) => row.idx}
          header={t.apiKey.listHeader}
          headerRight={translate(t.apiKey.countLabel, { count: items.length })}
          refreshing={loading}
          onRefresh={load}
          emptyMessage={t.apiKey.empty}
          item={(row) => ({
            icon: KeySquare,
            iconTone: isExpired(row.expired_at) ? 'destructive' : 'warning',
            title: row.name,
            subtitle: row.key,
            meta: fmtDate(row.expired_at),
            status: isExpired(row.expired_at)
              ? { label: t.apiKey.expired, tone: 'destructive' }
              : { label: t.apiKey.active, tone: 'success' },
          })}
        />
      </View>
    </DashboardLayout>
  )
}
