import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import { ApiKeyCreate, ApiKeyUpdate } from '@/packages/api-key/domain/api-key'
import { Repository as ApiKeyRepository } from '@/packages/api-key/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function useApiKeyUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const apiKeyRepository = new ApiKeyRepository(dataStoreApi)

  async function getAllApiKey(searchParams: IndexPageProps) {
    const response = await apiKeyRepository.getAllApiKey(searchParams)

    if (response.code !== 200) {
      return {
        docs: [],
        limit: 10,
        page: 1,
        pages: 0,
        total: 0,
      }
    }

    return {
      docs: response.data.data.docs,
      limit: response.data.data.limit,
      page: response.data.data.page,
      pages: response.data.data.pages,
      total: response.data.data.total,
    }
  }

  async function getOneApiKey(id: string) {
    const response = await apiKeyRepository.getOneApiKey(id)
    return response
  }

  async function createApiKey(data: ApiKeyCreate) {
    const response = await apiKeyRepository.createApiKey(data)
    return response
  }

  async function updateApiKey(data: ApiKeyUpdate) {
    const response = await apiKeyRepository.updateApiKey(data)
    return response
  }

  async function deleteApiKey(id: string) {
    const response = await apiKeyRepository.deleteApiKey(id)
    return response
  }

  return {
    getAllApiKey,
    getOneApiKey,
    createApiKey,
    updateApiKey,
    deleteApiKey,
  }
}
