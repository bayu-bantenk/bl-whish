import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import {
  UserBranchCreate,
  UserCreate,
  UserPrincipalCreate,
  UserUpdate,
} from '@/packages/user/domain/user'
import { Repository as UserRepository } from '@/packages/user/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function useUserUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const userRepository = new UserRepository(dataStoreApi)

  async function getAllUser(searchParams: IndexPageProps) {
    const response = await userRepository.getAllUser(searchParams)

    if (response.code !== 200) {
      return {
        docs: [],
        limit: 10,
        page: 1,
        pages: 0,
        total: 0,
      }
    }

    return {
      docs: response.data.data.docs,
      limit: response.data.data.limit,
      page: response.data.data.page,
      pages: response.data.data.pages,
      total: response.data.data.total,
    }
  }

  async function getSelectUser(searchParams: IndexPageProps) {
    const response = await userRepository.getSelectUser(searchParams)
    return response
  }

  async function getSelectUserPrincipal(searchParams: IndexPageProps) {
    const response = await userRepository.getSelectUserPrincipal(searchParams)
    return response
  }

  async function getOneUser(id: string) {
    const response = await userRepository.getOneUser(id)
    return response
  }

  async function createUser(data: UserCreate) {
    const response = await userRepository.createUser(data)
    return response
  }

  async function updateUser(data: UserUpdate) {
    const response = await userRepository.updateUser(data)
    return response
  }

  async function deleteUser(id: string) {
    const response = await userRepository.deleteUser(id)
    return response
  }

  async function updateUserBranch(data: UserBranchCreate) {
    const response = await userRepository.updateUserBranch(data)
    return response
  }

  async function updateUserPrincipal(data: UserPrincipalCreate) {
    const response = await userRepository.updateUserPrincipal(data)
    return response
  }

  return {
    getAllUser,
    getSelectUser,
    getSelectUserPrincipal,
    getOneUser,
    createUser,
    updateUser,
    deleteUser,
    updateUserBranch,
    updateUserPrincipal,
  }
}
