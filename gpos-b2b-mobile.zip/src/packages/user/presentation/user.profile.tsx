import { useNavigation } from '@react-navigation/native'
import { format } from 'date-fns'
import React, { useEffect, useState } from 'react'
import { View } from 'react-native'

import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import { Avatar, Button, Card, CardContent, Separator, Text } from '@/components/ui'
import useUserUseCase from '@/packages/user/usecases/usecase'
import { dashboardRoute } from '@/shared/constants'
import { useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'

export default function UserProfileView() {
  const navigation = useNavigation<any>()
  const { session, token } = useAuthSession()
  const userId = String(session?.idx ?? session?.id ?? '')

  const { getOneUser } = useUserUseCase(token)
  const { t } = useTranslation()

  const [datas, setDatas] = useState<any>(null)

  useEffect(() => {
    if (!token || !userId) return

    getOneUser(userId).then((data) => {
      if (data.code === 200) {
        setDatas(data.data.data)
      }
    })
  }, [token, userId])

  return (
    <DashboardLayout>
      <Header title={t.user.profile.title} />
      {datas ? (
        <View className="flex-1 gap-4 px-4 py-4">
          <View className="flex-row items-center gap-4">
            <Avatar>
              <Text>{(datas.fullname ?? 'U').slice(0, 2).toUpperCase()}</Text>
            </Avatar>
            <View>
              <Text className="text-xl font-bold">{datas.fullname}</Text>
              <Text className="text-sm text-muted-foreground">{datas.email}</Text>
            </View>
          </View>

          <Card>
            <CardContent className="gap-3 py-4">
              <View>
                <Text className="text-sm font-medium">{t.user.profile.name}</Text>
                <Text className="text-sm text-muted-foreground">
                  {datas.fullname}
                </Text>
              </View>
              <Separator />
              <View>
                <Text className="text-sm font-medium">{t.user.profile.email}</Text>
                <Text className="text-sm text-muted-foreground">{datas.email}</Text>
              </View>
              <Separator />
              <View>
                <Text className="text-sm font-medium">{t.user.profile.phone}</Text>
                <Text className="text-sm text-muted-foreground">
                  {datas.phone || '-'}
                </Text>
              </View>
              <Separator />
              <View>
                <Text className="text-sm font-medium">
                  {t.user.profile.createdDate}
                </Text>
                <Text className="text-sm text-muted-foreground">
                  {datas.created_at
                    ? format(new Date(datas.created_at), 'dd MMMM yyyy hh:mm a')
                    : '-'}
                </Text>
              </View>
            </CardContent>
          </Card>

          <Button
            variant="outline"
            onPress={() =>
              // UserUpdate lives in the Users tab stack, so navigate
              // through the tab navigator from the Profile tab.
              navigation.navigate('UserTab', {
                screen: dashboardRoute.userUpdate,
                params: { id: datas.idx },
              })
            }
          >
            <Text>{t.user.profile.update}</Text>
          </Button>
        </View>
      ) : null}
    </DashboardLayout>
  )
}
