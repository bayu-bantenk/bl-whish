import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigation, useRoute } from '@react-navigation/native'
import { AtSign, Lock, Mail, Phone, Shield, UserRound } from 'lucide-react-native'
import React, { useEffect, useState } from 'react'
import { Controller, type Resolver, useForm } from 'react-hook-form'
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import Toast from 'react-native-toast-message'

import { InputWithIcon, SelectField } from '@/components/molecules'
import { Header } from '@/components/organisms/header/header'
import { SelectSheet } from '@/components/organisms/select-sheet'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import {
  Alert,
  AlertDescription,
  AlertTitle,
  Button,
  Label,
  Spinner,
  Text,
} from '@/components/ui'
import type { Role } from '@/packages/role/domain/role'
import useRoleUseCase from '@/packages/role/usecases/usecase'
import {
  makeUserCreateFormSchema,
  makeUserEditFormSchema,
  type UserCreateFormSchema,
} from '@/packages/user/presentation/user.schema'
import useUserUseCase from '@/packages/user/usecases/usecase'
import { translate, useTranslation } from '@/shared/dictionaries'
import { dexain } from '@/shared/styles'
import { useAuthSession } from '@/shared/utils/auth'
import { cn } from '@/utils'

type FieldErrorTextProps = { message?: string }

function FieldErrorText({ message }: FieldErrorTextProps) {
  if (!message) return null
  return <Text className="text-xs text-destructive">{message}</Text>
}

export default function UserFormView() {
  const navigation = useNavigation<any>()
  const route = useRoute<any>()
  const id: string = route.params?.id ?? ''
  const isUpdate = Boolean(id)

  const { token } = useAuthSession()
  const { getOneUser, createUser, updateUser } = useUserUseCase(token)
  const { getAllRole } = useRoleUseCase(token)
  const { t } = useTranslation()

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [roles, setRoles] = useState<Role[]>([])
  const [rolePickerOpen, setRolePickerOpen] = useState(false)

  // Update mode validates identity fields only — passwords are managed by
  // their own flow, so the create schema would block every update. Schemas
  // are rebuilt per language so validation messages follow the dictionary.
  const formSchema = React.useMemo(
    () =>
      isUpdate
        ? makeUserEditFormSchema(t.user.validation)
        : makeUserCreateFormSchema(t.user.validation),
    [isUpdate, t]
  )

  const {
    control,
    handleSubmit,
    reset: resetForm,
    formState: { errors },
  } = useForm<UserCreateFormSchema>({
    resolver: zodResolver(formSchema) as unknown as Resolver<UserCreateFormSchema>,
    defaultValues: {
      fullname: '',
      username: '',
      email: '',
      role_id: 0,
      password: '',
      confirm: '',
      phone: '',
    },
  })

  useEffect(() => {
    if (!token) return

    getAllRole({ searchParams: {} }).then((data) => {
      setRoles(data.docs ?? [])
    })
  }, [token])

  useEffect(() => {
    if (!token || !isUpdate) return

    getOneUser(id).then((res) => {
      if (res.code === 200) {
        resetForm({
          fullname: res.data.data.fullname,
          username: res.data.data.username,
          email: res.data.data.email,
          phone: res.data.data.phone ?? '',
          role_id: res.data.data.role_id ?? 0,
        })
      }
    })
  }, [token, id, isUpdate])

  const onSubmit = async (data: UserCreateFormSchema) => {
    setLoading(true)
    setError('')

    try {
      if (isUpdate) {
        const response = await updateUser({
          id,
          username: data.username,
          email: data.email,
          password: '',
          is_change_password: '0',
          fullname: data.fullname,
          phone: data.phone,
          is_block: '0',
          role_id: Number(data.role_id),
        })

        if (response.code && response.code !== 200) {
          setLoading(false)
          setError(t.user.form.updateFailed)
          return
        }
      } else {
        const response = await createUser({
          username: data.username,
          email: data.email,
          password: data.password,
          fullname: data.fullname,
          phone: data.phone || '',
          role_id: Number(data.role_id),
        })

        if (response.code && response.code !== 200) {
          setLoading(false)
          setError(t.user.form.createFailed)
          return
        }
      }

      setLoading(false)
      Toast.show({
        type: 'success',
        text1: isUpdate ? t.user.form.toastUpdated : t.user.form.toastCreated,
        text2: translate(t.user.form.toastSaved, { name: data.fullname }),
      })
      navigation.goBack()
    } catch {
      setLoading(false)
      setError(t.common.errorGeneric)
    }
  }

  return (
    <DashboardLayout>
      <Header title={isUpdate ? t.user.form.updateTitle : t.user.form.createTitle} />
      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerClassName="gap-4 px-4 py-4"
          keyboardShouldPersistTaps="handled"
        >
          {error ? (
            <Alert variant="destructive">
              <AlertTitle>{t.common.oops}</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : null}

          {/* Section: identity */}
          <View className="gap-4 rounded-lg border border-border bg-card p-4">
            <View>
              <Text className="text-base font-bold">
                {t.user.form.identityTitle}
              </Text>
              <Text className="text-xs text-muted-foreground">
                {t.user.form.identitySubtitle}
              </Text>
            </View>

            <View className="gap-2">
              <Label nativeID="fullname" className="font-semibold">
                {t.user.form.fullname} <Text className="text-destructive">*</Text>
              </Label>
              <Controller
                control={control}
                name="fullname"
                render={({ field: { onChange, value } }) => (
                  <InputWithIcon
                    icon={UserRound}
                    placeholder={t.user.form.fullnamePlaceholder}
                    value={value}
                    onChangeText={onChange}
                    editable={!loading}
                    className={cn(errors.fullname && 'border-destructive')}
                  />
                )}
              />
              <FieldErrorText message={errors.fullname?.message} />
            </View>

            <View className="gap-2">
              <Label nativeID="username" className="font-semibold">
                {t.user.form.username} <Text className="text-destructive">*</Text>
              </Label>
              <Controller
                control={control}
                name="username"
                render={({ field: { onChange, value } }) => (
                  <InputWithIcon
                    icon={AtSign}
                    placeholder={t.user.form.usernamePlaceholder}
                    autoCapitalize="none"
                    value={value}
                    onChangeText={onChange}
                    editable={!loading && !isUpdate}
                    className={cn(
                      errors.username && 'border-destructive',
                      isUpdate && 'opacity-60'
                    )}
                  />
                )}
              />
              {isUpdate ? (
                <Text className="text-xs text-muted-foreground">
                  {t.user.form.usernameLocked}
                </Text>
              ) : (
                <FieldErrorText message={errors.username?.message} />
              )}
            </View>

            <View className="gap-2">
              <Label nativeID="email" className="font-semibold">
                {t.user.form.email} <Text className="text-destructive">*</Text>
              </Label>
              <Controller
                control={control}
                name="email"
                render={({ field: { onChange, value } }) => (
                  <InputWithIcon
                    icon={Mail}
                    placeholder="nama@aam.co.id"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={value}
                    onChangeText={onChange}
                    editable={!loading}
                    className={cn(errors.email && 'border-destructive')}
                  />
                )}
              />
              <FieldErrorText message={errors.email?.message} />
            </View>

            <View className="gap-2">
              <Label nativeID="phone" className="font-semibold">
                {t.user.form.phone}{' '}
                <Text className="font-normal text-muted-foreground">
                  {t.user.form.optional}
                </Text>
              </Label>
              <Controller
                control={control}
                name="phone"
                render={({ field: { onChange, value } }) => (
                  <InputWithIcon
                    icon={Phone}
                    placeholder="08xxxxxxxxxx"
                    keyboardType="phone-pad"
                    value={value}
                    onChangeText={onChange}
                    editable={!loading}
                  />
                )}
              />
            </View>
          </View>

          {/* Section: role */}
          <View className="gap-4 rounded-lg border border-border bg-card p-4">
            <View>
              <Text className="text-base font-bold">{t.user.form.roleTitle}</Text>
              <Text className="text-xs text-muted-foreground">
                {t.user.form.roleSubtitle}
              </Text>
            </View>

            <Controller
              control={control}
              name="role_id"
              render={({ field: { onChange, value } }) => {
                const selected = roles.find((role) => role.id === value)

                return (
                  <View className="gap-2">
                    <SelectField
                      icon={Shield}
                      placeholder={t.user.form.rolePlaceholder}
                      label={selected?.title ?? null}
                      error={Boolean(errors.role_id)}
                      disabled={loading}
                      onPress={() => setRolePickerOpen(true)}
                    />
                    <FieldErrorText message={errors.role_id?.message} />

                    <SelectSheet
                      open={rolePickerOpen}
                      onOpenChange={setRolePickerOpen}
                      title={t.user.form.roleSheetTitle}
                      options={roles.map((role) => ({
                        value: role.id,
                        label: role.title,
                        description: role.description,
                      }))}
                      value={value}
                      onSelect={onChange}
                      emptyMessage={t.user.form.roleEmpty}
                    />
                  </View>
                )
              }}
            />
          </View>

          {/* Section: security (create only) */}
          {!isUpdate ? (
            <View className="gap-4 rounded-lg border border-border bg-card p-4">
              <View>
                <Text className="text-base font-bold">
                  {t.user.form.securityTitle}
                </Text>
                <Text className="text-xs text-muted-foreground">
                  {t.user.form.securitySubtitle}
                </Text>
              </View>

              <View className="gap-2">
                <Label nativeID="password" className="font-semibold">
                  {t.user.form.password} <Text className="text-destructive">*</Text>
                </Label>
                <Controller
                  control={control}
                  name="password"
                  render={({ field: { onChange, value } }) => (
                    <InputWithIcon
                      icon={Lock}
                      secure
                      placeholder="●●●●●●●●"
                      value={value}
                      onChangeText={onChange}
                      editable={!loading}
                      className={cn(errors.password && 'border-destructive')}
                    />
                  )}
                />
                <FieldErrorText message={errors.password?.message} />
              </View>

              <View className="gap-2">
                <Label nativeID="confirm" className="font-semibold">
                  {t.user.form.confirmPassword}{' '}
                  <Text className="text-destructive">*</Text>
                </Label>
                <Controller
                  control={control}
                  name="confirm"
                  render={({ field: { onChange, value } }) => (
                    <InputWithIcon
                      icon={Lock}
                      secure
                      placeholder="●●●●●●●●"
                      value={value}
                      onChangeText={onChange}
                      editable={!loading}
                      className={cn(errors.confirm && 'border-destructive')}
                    />
                  )}
                />
                <FieldErrorText message={errors.confirm?.message} />
              </View>
            </View>
          ) : null}
        </ScrollView>

        {/* Sticky action bar */}
        <SafeAreaView edges={['bottom']} className="bg-card">
          <View className="flex-row gap-3 border-t border-border px-4 py-3">
            <Button
              variant="outline"
              className="flex-1"
              disabled={loading}
              onPress={() => navigation.goBack()}
            >
              <Text className="font-semibold">{t.common.cancel}</Text>
            </Button>
            <Button
              className="flex-1"
              disabled={loading}
              onPress={handleSubmit(onSubmit)}
            >
              {loading ? <Spinner className="mr-2" color={dexain.fgInvert} /> : null}
              <Text className="font-bold text-primary-foreground">
                {isUpdate ? t.user.form.submitUpdate : t.user.form.submitCreate}
              </Text>
            </Button>
          </View>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </DashboardLayout>
  )
}
