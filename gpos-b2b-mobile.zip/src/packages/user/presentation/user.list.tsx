import { useFocusEffect, useNavigation } from '@react-navigation/native'
import { LayoutGrid, List, Trash2, UserRound } from 'lucide-react-native'
import React, { useCallback, useState } from 'react'
import { Pressable, View } from 'react-native'

import { StatCard } from '@/components/molecules'
import { CardList } from '@/components/organisms/card-list'
import { DataTable, type DataTableColumn } from '@/components/organisms/data-table'
import { Header } from '@/components/organisms/header/header'
import { ConfirmModal } from '@/components/organisms/modal/confirm-modal'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import { Badge, Button, Text } from '@/components/ui'
import type { User } from '@/packages/user/domain/user'
import useUserUseCase from '@/packages/user/usecases/usecase'
import { dashboardRoute } from '@/shared/constants'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useDexain } from '@/shared/styles'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'
import { cn } from '@/utils'

type ViewMode = 'card' | 'table'

export default function UserListView() {
  const navigation = useNavigation<any>()
  const { token } = useAuthSession()
  const palette = useDexain()
  const { t } = useTranslation()
  const { getAllUser, deleteUser } = useUserUseCase(token)

  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(false)
  const [viewMode, setViewMode] = useState<ViewMode>('card')

  const load = useCallback(async () => {
    if (!token) return

    setLoading(true)
    const params: IndexPageProps = { searchParams: {} }
    const data = await getAllUser(params)
    setUsers(data.docs ?? [])
    setLoading(false)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  const [deleteTarget, setDeleteTarget] = useState<User | null>(null)
  const [deleting, setDeleting] = useState(false)

  const onDelete = (row: User) => setDeleteTarget(row)

  const confirmDelete = async () => {
    if (!deleteTarget) return

    setDeleting(true)
    await deleteUser(deleteTarget.idx)
    setDeleting(false)
    setDeleteTarget(null)
    load()
  }

  const openUpdate = (row: User) =>
    navigation.navigate(dashboardRoute.userUpdate, { id: row.idx })

  const active = users.filter((u) => u.is_block !== '1').length
  const blocked = users.length - active

  const columns: DataTableColumn<User>[] = [
    {
      id: 'user',
      header: t.user.columns.user,
      accessorKey: 'fullname',
      subAccessorKey: 'email',
      flex: 2,
    },
    {
      id: 'status',
      header: t.user.columns.status,
      align: 'right',
      cell: (row) => (
        <Badge variant={row.is_block === '1' ? 'destructive' : 'success'}>
          {row.is_block === '1' ? t.user.status.blocked : t.user.status.active}
        </Badge>
      ),
    },
  ]

  return (
    <DashboardLayout>
      <Header title={t.user.title}>
        <Button
          size="sm"
          onPress={() => navigation.navigate(dashboardRoute.userCreate)}
        >
          <Text className="text-primary-foreground">{t.user.create}</Text>
        </Button>
      </Header>
      <View className="flex-1 px-4 py-3">
        <View className="mb-3 flex-row gap-2.5">
          <StatCard label={t.user.stats.total} value={users.length} />
          <StatCard label={t.user.stats.active} value={active} tone="success" />
          <StatCard
            label={t.user.stats.blocked}
            value={blocked}
            tone="destructive"
          />
        </View>

        {/* Section header + card/table view toggle */}
        <View className="mb-2 flex-row items-center justify-between">
          <View className="flex-row items-baseline gap-2">
            <Text className="text-sm font-bold">{t.user.listHeader}</Text>
            <Text className="text-xs text-muted-foreground">
              {translate(t.user.countLabel, { count: users.length })}
            </Text>
          </View>
          <View className="flex-row overflow-hidden rounded-md border border-border">
            <Pressable
              accessibilityRole="button"
              onPress={() => setViewMode('card')}
              className={cn(
                'h-8 w-9 items-center justify-center',
                viewMode === 'card' ? 'bg-accent' : 'bg-card'
              )}
            >
              <List
                size={16}
                color={viewMode === 'card' ? palette.brand : palette.fg3}
              />
            </Pressable>
            <View className="w-px bg-border" />
            <Pressable
              accessibilityRole="button"
              onPress={() => setViewMode('table')}
              className={cn(
                'h-8 w-9 items-center justify-center',
                viewMode === 'table' ? 'bg-accent' : 'bg-card'
              )}
            >
              <LayoutGrid
                size={16}
                color={viewMode === 'table' ? palette.brand : palette.fg3}
              />
            </Pressable>
          </View>
        </View>

        {viewMode === 'card' ? (
          <CardList<User>
            data={users}
            keyExtractor={(row) => row.idx}
            refreshing={loading}
            onRefresh={load}
            emptyMessage={t.user.empty}
            item={(row) => ({
              icon: UserRound,
              iconTone: row.is_block === '1' ? 'destructive' : 'success',
              title: row.fullname,
              subtitle: row.email,
              status:
                row.is_block === '1'
                  ? { label: t.user.status.blocked, tone: 'destructive' }
                  : { label: t.user.status.active, tone: 'success' },
              chevron: true,
              onPress: () => openUpdate(row),
              onLongPress: () => onDelete(row),
            })}
          />
        ) : (
          <DataTable<User>
            data={users}
            columns={columns}
            keyExtractor={(row) => row.idx}
            refreshing={loading}
            onRefresh={load}
            emptyMessage={t.user.empty}
            onRowPress={openUpdate}
            onRowLongPress={onDelete}
          />
        )}
      </View>

      <ConfirmModal
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null)
        }}
        icon={Trash2}
        tone="destructive"
        title={t.user.delete.title}
        description={translate(t.user.delete.description, {
          name: deleteTarget?.fullname ?? '',
        })}
        confirmText={t.user.delete.confirm}
        cancelText={t.common.cancel}
        loading={deleting}
        onConfirm={confirmDelete}
      />
    </DashboardLayout>
  )
}
