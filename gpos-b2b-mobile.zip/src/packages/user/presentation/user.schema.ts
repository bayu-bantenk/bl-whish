import { z } from 'zod'

import { type Dictionary, en } from '@/shared/dictionaries'

/** Validation messages, taken from the active dictionary. */
type UserValidationMessages = Dictionary['user']['validation']

export const userTableSchema = z.object({
  id: z.number(),
  idx: z.string(),
  fullname: z.string(),
  email: z.string(),
  role: z.string(),
  is_block: z.string(),
  created_at: z.string(),
})

export type UserScheme = z.infer<typeof userTableSchema>

/** Fields shared by the create and edit forms. */
const userBaseFields = (v: UserValidationMessages) => ({
  fullname: z
    .string()
    .min(5, { message: v.fullnameMin })
    .max(50, { message: v.fullnameMax }),
  username: z
    .string()
    .min(5, { message: v.usernameMin })
    .max(20, { message: v.usernameMax })
    .refine((val) => !val.includes(' '), { message: v.usernameSpace }),
  email: z
    .string()
    .min(5, { message: v.emailMin })
    .email({ message: v.emailInvalid }),
  role_id: z.number().min(1, { message: v.roleRequired }),
  phone: z.string().optional(),
})

/** Create-mode schema with messages from the active dictionary. */
export const makeUserCreateFormSchema = (v: UserValidationMessages) =>
  z
    .object({
      ...userBaseFields(v),
      password: z
        .string()
        .min(8, { message: v.passwordMin })
        .max(16, { message: v.passwordMax })
        .regex(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%&*-])[A-Za-z\d!@#$%&*-]{8,}$/,
          { message: v.passwordPattern }
        ),
      confirm: z
        .string()
        .min(8, { message: v.passwordMin })
        .max(16, { message: v.passwordMax }),
    })
    .refine((data) => data.password === data.confirm, {
      message: v.passwordMismatch,
      path: ['confirm'],
    })

/** Edit mode: same identity fields, no password (changed via its own flow). */
export const makeUserEditFormSchema = (v: UserValidationMessages) =>
  z.object(userBaseFields(v))

/** Default-language (English) instances, kept for typing and static use. */
export const userCreateFormSchema = makeUserCreateFormSchema(en.user.validation)
export const userEditFormSchema = makeUserEditFormSchema(en.user.validation)

export type UserCreateFormSchema = z.infer<typeof userCreateFormSchema>
export type UserEditFormSchema = z.infer<typeof userEditFormSchema>

export const userUpdateDefaultFormSchema = z.object({
  fullname: z
    .string()
    .min(5, {
      message: 'Fullname must be at least 5 characters.',
    })
    .max(50, {
      message: 'Fullname must not be longer than 50 characters.',
    }),
  username: z
    .string()
    .min(5, {
      message: 'Username must be at least 5 characters.',
    })
    .max(20, {
      message: 'Username must not be longer than 20 characters.',
    })
    .refine((val) => !val.includes(' '), {
      message: "Username can't be included space. Please use underscore.",
    }),
  email: z.string().min(5, {
    message: 'Email must be at least 5 characters.',
  }),
  role_id: z.number().refine((val) => val !== undefined && val !== null, {
    message: 'Please select a role.',
  }),
  phone: z.string().optional(),
  is_block: z.string(),
  is_change_password: z.string().default('0'),
})

export const userUpdatePasswordFormSchema = z.object({
  is_change_password: z.literal('1'),
  password: z
    .string()
    .min(8, {
      message: 'Password must be at least 8 characters.',
    })
    .max(16, {
      message: 'Password must not be longer than 16 characters.',
    })
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%&*-])[A-Za-z\d!@#$%&*-]{8,}$/,
      {
        message:
          'Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character.',
      }
    ),
  confirm: z
    .string()
    .min(8, {
      message: 'Password must be at least 8 characters.',
    })
    .max(16, {
      message: 'Password must not be longer than 16 characters.',
    }),
})

export const userUpdateNoPasswordFormSchema = z.object({
  is_change_password: z.literal('0'),
})

const userUpdateFormCond = z
  .discriminatedUnion('is_change_password', [
    userUpdatePasswordFormSchema,
    userUpdateNoPasswordFormSchema,
  ])
  .refine(
    (data) =>
      data.is_change_password === '1' ? data.password === data.confirm : true,
    {
      message: "Passwords don't match",
      path: ['confirm'],
    }
  )

export const userUpdateFormSchema = z.intersection(
  userUpdateFormCond,
  userUpdateDefaultFormSchema
)

export type UserUpdateFormSchema = z.infer<typeof userUpdateFormSchema>
