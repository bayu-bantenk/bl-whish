export type User = {
  id: number
  idx: string
  username: string
  email: string
  password: string
  fullname: string
  is_block: string
  activation_key: string
  forget_key: string
  phone: string
  phone_otp: string
  phone_verified: string
  created_by: number
  updated_by: number
  created_at: string
  updated_at: string
}

export type UserTable = {
  docs: User[]
  limit: number
  page: number
  pages: number
  total: number
}

export type UserCreate = {
  username: string
  email: string
  password: string
  fullname: string
  phone: string | undefined
  role_id: number
}

export type UserUpdate = {
  id: string
  username: string
  email: string
  password: string
  is_change_password: string
  fullname: string
  phone: string | undefined
  is_block: string
  role_id: number
}

export type UserBranchCreate = {
  user_id: number
  branches: string[]
}

export type UserPrincipalCreate = {
  user_id: number
  principals: string[]
}
