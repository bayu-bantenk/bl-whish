import {
  UserBranchCreate,
  UserCreate,
  UserPrincipalCreate,
  UserUpdate,
} from '@/packages/user/domain/user'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IUserRepository {
  getAllUser: (params: IndexPageProps) => Promise<any>
  getSelectUser: (params: IndexPageProps) => Promise<any>
  getSelectUserPrincipal: (params: IndexPageProps) => Promise<any>
  getOneUser: (id: string) => Promise<any>
  createUser: (data: UserCreate) => Promise<any>
  updateUser: (data: UserUpdate) => Promise<any>
  deleteUser: (id: string) => Promise<any>
  updateUserBranch: (data: UserBranchCreate) => Promise<any>
  updateUserPrincipal: (data: UserPrincipalCreate) => Promise<any>
}

export class Repository implements IUserRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getAllUser(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/users', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getSelectUser(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/users/select', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getSelectUserPrincipal(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get(
        '/users/principal',
        params.searchParams
      )

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getOneUser(id: string): Promise<any> {
    try {
      const response: any = await this.api.get(`/users/${id}`)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      delete response.data.data.password
      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async createUser(data: UserCreate): Promise<any> {
    try {
      const response: any = await this.api.post(`/users`, data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async updateUser(data: UserUpdate): Promise<any> {
    try {
      const response: any = await this.api.put(`/users`, data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async deleteUser(id: string): Promise<any> {
    try {
      const response: any = await this.api.delete(`/users`, { id: id })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          status: 'error',
        }
      }

      return {
        code: response.code,
        message: response.message,
        status: 'success',
      }
    } catch (error) {
      return {
        code: 500,
        message: error,
        status: 'error',
      }
    }
  }

  async updateUserBranch(data: UserBranchCreate): Promise<any> {
    try {
      const response: any = await this.api.post(`/users/create/branch`, data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async updateUserPrincipal(data: UserPrincipalCreate): Promise<any> {
    try {
      const response: any = await this.api.post(`/users/create/principal`, data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }
}
