export type Workflow = {
  id: number
  idx: string
  name: string
  status: string
  created_at: string
  updated_at: string
}

export type WorkflowTable = {
  docs: Workflow[]
  limit: number
  page: number
  pages: number
  total: number
}

export type WorkflowCreate = {
  name: string
  status: string
}

export type WorkflowUpdate = {
  id: string
  name: string
  status: string
}
