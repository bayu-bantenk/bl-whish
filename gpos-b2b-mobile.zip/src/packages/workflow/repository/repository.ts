import { WorkflowCreate, WorkflowUpdate } from '@/packages/workflow/domain/workflow'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IWorkflowRepository {
  getAllWorkflow: (params: IndexPageProps) => Promise<any>
  getOneWorkflow: (id: string) => Promise<any>
  createWorkflow: (data: WorkflowCreate) => Promise<any>
  updateWorkflow: (data: WorkflowUpdate) => Promise<any>
}

export class Repository implements IWorkflowRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getAllWorkflow(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get('/workflows', params.searchParams)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getOneWorkflow(id: string): Promise<any> {
    try {
      const response: any = await this.api.get(`/workflows/${id}`)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async createWorkflow(data: WorkflowCreate): Promise<any> {
    try {
      const response: any = await this.api.post('/workflows', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async updateWorkflow(data: WorkflowUpdate): Promise<any> {
    try {
      const response: any = await this.api.put('/workflows', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }
}
