import { z } from 'zod'

export const workflowTableSchema = z.object({
  id: z.number(),
  idx: z.string(),
  name: z.string(),
  status: z.string(),
  created_at: z.string(),
})

export type WorkflowScheme = z.infer<typeof workflowTableSchema>

export const workflowFormSchema = z.object({
  name: z
    .string()
    .min(3, {
      message: 'Name must be at least 3 characters.',
    })
    .max(50, {
      message: 'Name must not be longer than 50 characters.',
    }),
  status: z.string().min(1, {
    message: 'Please select a status.',
  }),
})

export type WorkflowFormSchema = z.infer<typeof workflowFormSchema>
