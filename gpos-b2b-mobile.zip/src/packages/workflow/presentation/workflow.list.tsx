import { useFocusEffect } from '@react-navigation/native'
import { format } from 'date-fns'
import { Workflow as WorkflowIcon } from 'lucide-react-native'
import React, { useCallback, useState } from 'react'
import { View } from 'react-native'

import { CardList } from '@/components/organisms/card-list'
import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import type { Workflow } from '@/packages/workflow/domain/workflow'
import useWorkflowUseCase from '@/packages/workflow/usecases/usecase'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'

const fmtDate = (value: string) => {
  const date = new Date(value)
  return isNaN(+date) ? undefined : format(date, 'dd MMM yyyy')
}

const isActive = (status: string) => /aktif|active|selesai|done/i.test(status)

export default function WorkflowListView() {
  const { token } = useAuthSession()
  const { getAllWorkflow } = useWorkflowUseCase(token)
  const { t } = useTranslation()

  const [items, setItems] = useState<Workflow[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    if (!token) return

    setLoading(true)
    const params: IndexPageProps = { searchParams: {} }
    const data = await getAllWorkflow(params)
    setItems(data.docs ?? [])
    setLoading(false)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  return (
    <DashboardLayout>
      <Header title={t.workflow.title} />
      <View className="flex-1 px-4 py-3">
        <CardList<Workflow>
          data={items}
          keyExtractor={(row) => row.idx}
          header={t.workflow.listHeader}
          headerRight={translate(t.workflow.countLabel, { count: items.length })}
          refreshing={loading}
          onRefresh={load}
          emptyMessage={t.workflow.empty}
          item={(row) => ({
            icon: WorkflowIcon,
            iconTone: 'info',
            title: row.name,
            meta: fmtDate(row.created_at),
            status: row.status
              ? {
                  label: row.status,
                  tone: isActive(row.status) ? 'success' : 'secondary',
                }
              : undefined,
          })}
        />
      </View>
    </DashboardLayout>
  )
}
