import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import { WorkflowCreate, WorkflowUpdate } from '@/packages/workflow/domain/workflow'
import { Repository as WorkflowRepository } from '@/packages/workflow/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function useWorkflowUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const workflowRepository = new WorkflowRepository(dataStoreApi)

  async function getAllWorkflow(searchParams: IndexPageProps) {
    const response = await workflowRepository.getAllWorkflow(searchParams)

    if (response.code !== 200) {
      return {
        docs: [],
        limit: 10,
        page: 1,
        pages: 0,
        total: 0,
      }
    }

    return {
      docs: response.data.data.docs,
      limit: response.data.data.limit,
      page: response.data.data.page,
      pages: response.data.data.pages,
      total: response.data.data.total,
    }
  }

  async function getOneWorkflow(id: string) {
    const response = await workflowRepository.getOneWorkflow(id)
    return response
  }

  async function createWorkflow(data: WorkflowCreate) {
    const response = await workflowRepository.createWorkflow(data)
    return response
  }

  async function updateWorkflow(data: WorkflowUpdate) {
    const response = await workflowRepository.updateWorkflow(data)
    return response
  }

  return {
    getAllWorkflow,
    getOneWorkflow,
    createWorkflow,
    updateWorkflow,
  }
}
