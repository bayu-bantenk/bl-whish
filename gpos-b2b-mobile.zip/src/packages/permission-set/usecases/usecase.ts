import axios, { AxiosInstance } from 'axios'
import Config from 'react-native-config'

import {
  PermissionSetCreate,
  PermissionSetUpdate,
} from '@/packages/permission-set/domain/permission-set'
import { Repository as PermissionSetRepository } from '@/packages/permission-set/repository/repository'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export default function usePermissionSetUseCase(token?: string | null) {
  const http: AxiosInstance = axios.create({
    baseURL: Config.API_HOST,
    timeout: 30000,
  })
  const dataStoreApi = new RestAPI(http, token)
  const permissionSetRepository = new PermissionSetRepository(dataStoreApi)

  async function getAllPermissionSet(searchParams: IndexPageProps) {
    const response = await permissionSetRepository.getAllPermissionSet(searchParams)

    if (response.code !== 200) {
      return {
        docs: [],
        limit: 10,
        page: 1,
        pages: 0,
        total: 0,
      }
    }

    return {
      docs: response.data.data.docs,
      limit: response.data.data.limit,
      page: response.data.data.page,
      pages: response.data.data.pages,
      total: response.data.data.total,
    }
  }

  async function getOnePermissionSet(id: string) {
    const response = await permissionSetRepository.getOnePermissionSet(id)
    return response
  }

  async function createPermissionSet(data: PermissionSetCreate) {
    const response = await permissionSetRepository.createPermissionSet(data)
    return response
  }

  async function updatePermissionSet(data: PermissionSetUpdate) {
    const response = await permissionSetRepository.updatePermissionSet(data)
    return response
  }

  async function deletePermissionSet(id: string) {
    const response = await permissionSetRepository.deletePermissionSet(id)
    return response
  }

  return {
    getAllPermissionSet,
    getOnePermissionSet,
    createPermissionSet,
    updatePermissionSet,
    deletePermissionSet,
  }
}
