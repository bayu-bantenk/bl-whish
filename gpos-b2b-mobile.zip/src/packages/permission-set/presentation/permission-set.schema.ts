import { z } from 'zod'

export const permissionSetTableSchema = z.object({
  id: z.number(),
  idx: z.string(),
  name: z.string(),
  code: z.string(),
  created_at: z.string(),
})

export type PermissionSetScheme = z.infer<typeof permissionSetTableSchema>

export const permissionSetFormSchema = z.object({
  name: z
    .string()
    .min(3, {
      message: 'Name must be at least 3 characters.',
    })
    .max(50, {
      message: 'Name must not be longer than 50 characters.',
    }),
  code: z
    .string()
    .min(2, {
      message: 'Code must be at least 2 characters.',
    })
    .max(50, {
      message: 'Code must not be longer than 50 characters.',
    }),
})

export type PermissionSetFormSchema = z.infer<typeof permissionSetFormSchema>
