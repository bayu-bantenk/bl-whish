import { useFocusEffect } from '@react-navigation/native'
import { ShieldCheck } from 'lucide-react-native'
import React, { useCallback, useState } from 'react'
import { View } from 'react-native'

import { CardList } from '@/components/organisms/card-list'
import { Header } from '@/components/organisms/header/header'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import type { PermissionSet } from '@/packages/permission-set/domain/permission-set'
import usePermissionSetUseCase from '@/packages/permission-set/usecases/usecase'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useAuthSession } from '@/shared/utils/auth'
import type { IndexPageProps } from '@/shared/utils/type'

export default function PermissionSetListView() {
  const { token } = useAuthSession()
  const { getAllPermissionSet } = usePermissionSetUseCase(token)
  const { t } = useTranslation()

  const [items, setItems] = useState<PermissionSet[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    if (!token) return

    setLoading(true)
    const params: IndexPageProps = { searchParams: {} }
    const data = await getAllPermissionSet(params)
    setItems(data.docs ?? [])
    setLoading(false)
  }, [token])

  // useFocusEffect also runs on the initial focus, so no mount effect needed.
  useFocusEffect(
    useCallback(() => {
      load()
    }, [load])
  )

  return (
    <DashboardLayout>
      <Header title={t.permissionSet.title} />
      <View className="flex-1 px-4 py-3">
        <CardList<PermissionSet>
          data={items}
          keyExtractor={(row) => row.idx}
          header={t.permissionSet.listHeader}
          headerRight={translate(t.permissionSet.countLabel, {
            count: items.length,
          })}
          refreshing={loading}
          onRefresh={load}
          emptyMessage={t.permissionSet.empty}
          item={(row) => ({
            icon: ShieldCheck,
            iconTone: 'primary',
            title: row.name,
            subtitle: row.code,
          })}
        />
      </View>
    </DashboardLayout>
  )
}
