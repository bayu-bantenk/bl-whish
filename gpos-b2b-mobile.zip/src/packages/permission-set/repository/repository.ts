import {
  PermissionSetCreate,
  PermissionSetUpdate,
} from '@/packages/permission-set/domain/permission-set'
import { RestAPI } from '@/shared/utils/rest-api'
import type { IndexPageProps } from '@/shared/utils/type'

export interface IPermissionSetRepository {
  getAllPermissionSet: (params: IndexPageProps) => Promise<any>
  getOnePermissionSet: (id: string) => Promise<any>
  createPermissionSet: (data: PermissionSetCreate) => Promise<any>
  updatePermissionSet: (data: PermissionSetUpdate) => Promise<any>
  deletePermissionSet: (id: string) => Promise<any>
}

export class Repository implements IPermissionSetRepository {
  private api: RestAPI

  constructor(api: RestAPI) {
    this.api = api
  }

  async getAllPermissionSet(params: IndexPageProps): Promise<any> {
    try {
      const response: any = await this.api.get(
        '/permission-sets',
        params.searchParams
      )

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async getOnePermissionSet(id: string): Promise<any> {
    try {
      const response: any = await this.api.get(`/permission-sets/${id}`)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async createPermissionSet(data: PermissionSetCreate): Promise<any> {
    try {
      const response: any = await this.api.post('/permission-sets', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async updatePermissionSet(data: PermissionSetUpdate): Promise<any> {
    try {
      const response: any = await this.api.put('/permission-sets', data)

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          data: {},
          status: 'error',
        }
      }

      return response.data
    } catch (error) {
      return {
        code: 500,
        message: error,
        data: {},
        status: 'error',
      }
    }
  }

  async deletePermissionSet(id: string): Promise<any> {
    try {
      const response: any = await this.api.delete('/permission-sets', { id: id })

      if (response.code !== 200) {
        return {
          code: response.code,
          message: response.message,
          status: 'error',
        }
      }

      return {
        code: response.code,
        message: response.message,
        status: 'success',
      }
    } catch (error) {
      return {
        code: 500,
        message: error,
        status: 'error',
      }
    }
  }
}
