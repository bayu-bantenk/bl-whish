export type PermissionSet = {
  id: number
  idx: string
  name: string
  code: string
  created_at: string
  updated_at: string
}

export type PermissionSetTable = {
  docs: PermissionSet[]
  limit: number
  page: number
  pages: number
  total: number
}

export type PermissionSetCreate = {
  name: string
  code: string
}

export type PermissionSetUpdate = {
  id: string
  name: string
  code: string
}
