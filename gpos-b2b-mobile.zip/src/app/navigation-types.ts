import type { NavigatorScreenParams } from '@react-navigation/native'

/**
 * Root — decides between the Auth flow and the Dashboard flow based on the
 * authenticated session (mirrors the Next.js route groups).
 */
export type RootStackParamList = {
  Auth: NavigatorScreenParams<AuthStackParamList> | undefined
  Dashboard: NavigatorScreenParams<DashboardTabParamList> | undefined
}

/** (auth) route group -> native-stack */
export type AuthStackParamList = {
  Login: undefined
  Register: undefined
  Forgot: undefined
  Reset: { token?: string } | undefined
}

/** (dashboard) route group -> bottom tabs */
export type DashboardTabParamList = {
  HomeTab: undefined
  UserTab: NavigatorScreenParams<UserStackParamList> | undefined
  RoleTab: NavigatorScreenParams<RoleStackParamList> | undefined
  MenuTab: NavigatorScreenParams<MenuStackParamList> | undefined
}

/** Menu tab stack — "Semua Fitur" list plus every feature screen it opens */
export type MenuStackParamList = {
  MenuList: undefined
  Profile: undefined
  Settings: undefined
  PermissionSet: undefined
  AuditLog: undefined
  Attribute: undefined
  ApiKey: undefined
  Workflow: undefined
}

/** User feature stack (list/create/update) */
export type UserStackParamList = {
  UserList: undefined
  UserCreate: undefined
  UserUpdate: { id: string }
}

/** Role feature stack (list only for skeleton) */
export type RoleStackParamList = {
  RoleList: undefined
}

declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
