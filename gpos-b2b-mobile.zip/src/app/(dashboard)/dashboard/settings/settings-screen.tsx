import {
  CircleHelp,
  Info,
  Languages,
  Palette,
  SunMoon,
  Tag,
} from 'lucide-react-native'
import * as React from 'react'
import { Linking, ScrollView } from 'react-native'
import Config from 'react-native-config'

import { ListItemCard } from '@/components/molecules'
import { ConfirmModal } from '@/components/organisms/modal/confirm-modal'
import { SelectSheet } from '@/components/organisms/select-sheet'
import { DashboardLayout } from '@/components/templates/dashboard-layout'
import { Text } from '@/components/ui'
import { type Language, translate, useTranslation } from '@/shared/dictionaries'
import {
  brandThemes,
  type ThemeId,
  type ThemeMode,
  useThemeStore,
} from '@/shared/styles'

import pkg from '../../../../../package.json'

/** Sample support address — point this at the real helpdesk per project. */
const SUPPORT_EMAIL = 'support@aam.co.id'

export function SettingsScreen() {
  const [aboutOpen, setAboutOpen] = React.useState(false)
  const [helpOpen, setHelpOpen] = React.useState(false)
  const [themeOpen, setThemeOpen] = React.useState(false)
  const [modeOpen, setModeOpen] = React.useState(false)
  const [languageOpen, setLanguageOpen] = React.useState(false)

  const { themeId, setThemeId, mode, setMode } = useThemeStore()
  const { t, language, setLanguage } = useTranslation()

  const modeOptions: { value: ThemeMode; label: string; description: string }[] = [
    {
      value: 'light',
      label: t.settings.mode.light,
      description: t.settings.mode.lightDescription,
    },
    {
      value: 'dark',
      label: t.settings.mode.dark,
      description: t.settings.mode.darkDescription,
    },
    {
      value: 'system',
      label: t.settings.mode.system,
      description: t.settings.mode.systemDescription,
    },
  ]
  const modeLabel = modeOptions.find((option) => option.value === mode)?.label

  const languageOptions: {
    value: Language
    label: string
    description: string
  }[] = [
    {
      value: 'en',
      label: t.settings.language.english,
      description: t.settings.language.englishDescription,
    },
    {
      value: 'id',
      label: t.settings.language.indonesian,
      description: t.settings.language.indonesianDescription,
    },
  ]
  const languageLabel = languageOptions.find(
    (option) => option.value === language
  )?.label

  const appName = Config.APP_NAME ?? 'Hexenrn'

  return (
    <DashboardLayout title={t.settings.title}>
      <ScrollView contentContainerClassName="px-4 py-4">
        <Text className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {t.settings.preferences}
        </Text>

        <ListItemCard
          icon={Palette}
          iconTone="primary"
          title={t.settings.theme.title}
          subtitle={t.settings.theme.subtitle}
          meta={brandThemes[themeId].label}
          chevron
          onPress={() => setThemeOpen(true)}
          className="mb-2.5"
        />
        <ListItemCard
          icon={SunMoon}
          iconTone="primary"
          title={t.settings.mode.title}
          subtitle={t.settings.mode.subtitle}
          meta={modeLabel}
          chevron
          onPress={() => setModeOpen(true)}
          className="mb-2.5"
        />
        <ListItemCard
          icon={Languages}
          iconTone="primary"
          title={t.settings.language.title}
          subtitle={t.settings.language.subtitle}
          meta={languageLabel}
          chevron
          onPress={() => setLanguageOpen(true)}
          className="mb-2.5"
        />

        <Text className="mb-2 mt-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {t.settings.aboutSection}
        </Text>

        <ListItemCard
          icon={Info}
          iconTone="primary"
          title={t.settings.about.title}
          subtitle={t.settings.about.subtitle}
          chevron
          onPress={() => setAboutOpen(true)}
          className="mb-2.5"
        />
        <ListItemCard
          icon={CircleHelp}
          iconTone="info"
          title={t.settings.help.title}
          subtitle={t.settings.help.subtitle}
          chevron
          onPress={() => setHelpOpen(true)}
          className="mb-2.5"
        />
        <ListItemCard
          icon={Tag}
          iconTone="default"
          title={t.settings.version.title}
          subtitle={translate(t.settings.version.subtitle, {
            channel: __DEV__ ? 'DEV' : 'PROD',
          })}
          meta={`v${pkg.version}`}
        />
      </ScrollView>

      <SelectSheet<ThemeMode>
        open={modeOpen}
        onOpenChange={setModeOpen}
        title={t.settings.mode.sheetTitle}
        options={modeOptions}
        value={mode}
        onSelect={setMode}
      />

      <SelectSheet<ThemeId>
        open={themeOpen}
        onOpenChange={setThemeOpen}
        title={t.settings.theme.sheetTitle}
        options={(Object.keys(brandThemes) as ThemeId[]).map((id) => ({
          value: id,
          label: brandThemes[id].label,
          description:
            id === 'blue'
              ? t.settings.theme.blueDescription
              : t.settings.theme.redDescription,
        }))}
        value={themeId}
        onSelect={setThemeId}
      />

      <SelectSheet<Language>
        open={languageOpen}
        onOpenChange={setLanguageOpen}
        title={t.settings.language.sheetTitle}
        options={languageOptions}
        value={language}
        onSelect={setLanguage}
      />

      <ConfirmModal
        open={aboutOpen}
        onOpenChange={setAboutOpen}
        icon={Info}
        tone="info"
        title={appName}
        description={translate(t.settings.about.description, {
          appName,
          version: pkg.version,
        })}
        confirmText={t.common.ok}
      />

      <ConfirmModal
        open={helpOpen}
        onOpenChange={setHelpOpen}
        icon={CircleHelp}
        tone="primary"
        title={t.settings.help.title}
        description={translate(t.settings.help.description, {
          email: SUPPORT_EMAIL,
        })}
        confirmText={t.settings.help.confirm}
        cancelText={t.common.cancel}
        onConfirm={() => {
          setHelpOpen(false)
          Linking.openURL(`mailto:${SUPPORT_EMAIL}`)
        }}
      />
    </DashboardLayout>
  )
}
