import { useIsFocused, useNavigation } from '@react-navigation/native'
import {
  Bell,
  BriefcaseBusiness,
  ChevronRight,
  CircleUser,
  FileText,
  FolderOpen,
  FolderSync,
  LayoutGrid,
  Lock,
  LogOut,
  type LucideIcon,
  Settings,
  Shield,
  Users,
} from 'lucide-react-native'
import * as React from 'react'
import { Pressable, ScrollView, StatusBar, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'

import { ConfirmModal } from '@/components/organisms/modal/confirm-modal'
import { Avatar, Badge, Card, Separator, Text } from '@/components/ui'
import { type Dictionary, translate, useTranslation } from '@/shared/dictionaries'
import { useDexain } from '@/shared/styles'
import { postLogout, useAuthSession } from '@/shared/utils/auth'

/**
 * Sample data — replace with real data sources per project. The layout below
 * (greeting header, summary card, feature grid, priority list) is the
 * standard company home-screen pattern.
 */
const sampleSummary = {
  reference: '2026-0801-001',
  done: 24,
  target: 36,
  breakdown: [
    { key: 'done', value: 24 },
    { key: 'inProgress', value: 8 },
    { key: 'cancelled', value: 2 },
  ] as { key: keyof Dictionary['home']['breakdown']; value: number }[],
}

type FeatureItem = {
  labelKey: keyof Dictionary['home']['featureLabels']
  icon: LucideIcon
  /** Tab route to open; sample tiles without a target are inert. */
  route?: string
  /** Screen inside the target tab's stack. */
  screen?: string
}

const features: FeatureItem[] = [
  { labelKey: 'users', icon: Users, route: 'UserTab' },
  { labelKey: 'roles', icon: Shield, route: 'RoleTab' },
  { labelKey: 'profile', icon: CircleUser, route: 'MenuTab', screen: 'Profile' },
  { labelKey: 'reports', icon: FileText },
  { labelKey: 'documents', icon: FolderOpen },
  { labelKey: 'sync', icon: FolderSync },
  { labelKey: 'settings', icon: Settings, route: 'MenuTab', screen: 'Settings' },
  { labelKey: 'all', icon: LayoutGrid, route: 'MenuTab' },
]

function getGreeting(t: Dictionary, date = new Date()): string {
  const hour = date.getHours()
  if (hour < 11) return t.home.greetingMorning
  if (hour < 15) return t.home.greetingNoon
  if (hour < 19) return t.home.greetingAfternoon
  return t.home.greetingEvening
}

/**
 * Drives the OS status bar to match the screen: navy with light icons while
 * Home (dark header) is focused, back to the light app default otherwise.
 * Rendered unconditionally — tab screens stay mounted, so this is the single
 * source of truth and there is no stale state when switching tabs.
 * `backgroundColor` is Android-only; on iOS the navy SafeAreaView paints the
 * area behind the status bar.
 */
function FocusAwareStatusBar() {
  const isFocused = useIsFocused()
  const palette = useDexain()

  return (
    <StatusBar
      animated
      barStyle={
        isFocused || palette.scheme === 'dark' ? 'light-content' : 'dark-content'
      }
      // Other tabs have surface-colored headers, so follow the surface color
      // (white in light mode, dark in dark mode) when unfocused.
      backgroundColor={isFocused ? palette.brandDeep : palette.bgSurface}
    />
  )
}

export function HomeScreen() {
  const navigation = useNavigation<any>()
  const { session } = useAuthSession()
  const palette = useDexain()
  const { t } = useTranslation()

  const name = session?.name || t.common.user
  const initials = name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()

  const progress = Math.min(
    Math.round((sampleSummary.done / sampleSummary.target) * 100),
    100
  )
  const remaining = Math.max(sampleSummary.target - sampleSummary.done, 0)

  const [logoutOpen, setLogoutOpen] = React.useState(false)

  return (
    <View className="flex-1 bg-background">
      <FocusAwareStatusBar />
      <SafeAreaView edges={['top']} className="bg-primary-deep" />

      <ScrollView contentContainerClassName="pb-6">
        {/* Greeting header */}
        <View className="bg-primary-deep px-4 pb-14 pt-3">
          <View className="flex-row items-center gap-3">
            <Avatar className="h-12 w-12 bg-card">
              <Text className="font-bold text-primary-deep">{initials}</Text>
            </Avatar>
            <View className="flex-1">
              <Text className="text-sm text-primary-foreground/70">
                {getGreeting(t)}
              </Text>
              <Text className="text-lg font-bold text-primary-foreground">
                {name}
              </Text>
            </View>
            <Pressable
              accessibilityRole="button"
              className="relative h-11 w-11 items-center justify-center rounded-md bg-white/10 active:bg-white/20"
            >
              <Bell size={20} color={palette.fgInvert} />
              <View className="absolute right-3 top-3 h-2 w-2 rounded-full bg-destructive" />
            </Pressable>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={t.home.logout}
              onPress={() => setLogoutOpen(true)}
              className="h-11 w-11 items-center justify-center rounded-md bg-white/10 active:bg-white/20"
            >
              <LogOut size={20} color={palette.fgInvert} />
            </Pressable>
          </View>

          <View className="mt-3 flex-row items-center gap-2">
            <View className="flex-row items-center gap-1.5 rounded-full bg-white/10 px-3 py-1">
              <BriefcaseBusiness size={13} color={palette.fgInvert} />
              <Text className="text-xs font-medium text-primary-foreground">
                {t.common.employeeBadge}
              </Text>
            </View>
            <View className="rounded-full bg-warning-soft px-3 py-1">
              <Text className="text-xs font-semibold text-warning">
                {translate(t.common.pendingBadge, { count: remaining })}
              </Text>
            </View>
          </View>
        </View>

        {/* Summary card, overlapping the header */}
        <View className="-mt-10 px-4">
          <Card className="gap-3 p-4">
            <View className="flex-row items-center justify-between">
              <Text className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {t.home.summaryTitle}
              </Text>
              <Badge variant="success">{t.home.activeBadge}</Badge>
            </View>
            <Text className="text-xl font-bold">{sampleSummary.reference}</Text>

            <View className="flex-row items-end justify-between">
              <View>
                <Text className="text-sm text-muted-foreground">
                  {t.home.doneToday}
                </Text>
                <Text className="text-3xl font-bold text-primary">
                  {sampleSummary.done}
                </Text>
              </View>
              <View className="items-end">
                <Text className="text-sm text-muted-foreground">
                  {t.home.target}
                </Text>
                <Text className="text-base font-semibold">
                  {sampleSummary.target}
                </Text>
              </View>
            </View>

            <View className="h-2 w-full overflow-hidden rounded-full bg-muted">
              <View
                className="h-full rounded-full bg-primary"
                style={{ width: `${progress}%` }}
              />
            </View>
            <View className="flex-row items-center justify-between">
              <Text className="text-xs text-muted-foreground">
                {translate(t.home.progressAchieved, { progress })}
              </Text>
              <Text className="text-xs text-muted-foreground">
                {translate(t.home.tasksRemaining, { count: remaining })}
              </Text>
            </View>

            <Separator />

            <View className="flex-row">
              {sampleSummary.breakdown.map((item) => (
                <View key={item.key} className="flex-1">
                  <Text className="text-xs text-muted-foreground">
                    {t.home.breakdown[item.key]}
                  </Text>
                  <Text className="text-base font-semibold">{item.value}</Text>
                </View>
              ))}
            </View>
          </Card>
        </View>

        {/* Feature grid */}
        <View className="mt-6 px-4">
          <View className="mb-3 flex-row items-center justify-between">
            <Text className="text-lg font-bold">{t.home.features}</Text>
            <Text
              className="text-sm font-semibold text-primary"
              onPress={() => navigation.navigate('MenuTab')}
            >
              {t.home.allFeatures}
            </Text>
          </View>
          <View className="flex-row flex-wrap justify-between gap-y-3">
            {features.map((item) => (
              <Pressable
                key={item.labelKey}
                accessibilityRole="button"
                onPress={
                  item.route
                    ? () =>
                        navigation.navigate(
                          item.route,
                          item.screen
                            ? // initial:false keeps the tab's list screen
                              // beneath, so the back button works.
                              { screen: item.screen, initial: false }
                            : undefined
                        )
                    : undefined
                }
                className="w-[23%] items-center gap-2 rounded-lg border border-border bg-card py-3 active:bg-accent"
              >
                <View className="h-10 w-10 items-center justify-center rounded-md bg-accent">
                  <item.icon size={20} color={palette.brand} />
                </View>
                <Text className="text-center text-xs" numberOfLines={1}>
                  {t.home.featureLabels[item.labelKey]}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Priority list */}
        <View className="mt-6 px-4">
          <Text className="mb-3 text-lg font-bold">{t.home.priorityTitle}</Text>
          <Card className="flex-row items-center gap-3 p-4">
            <View className="h-10 w-10 items-center justify-center rounded-md bg-warning-soft">
              <Lock size={18} color={palette.warn} />
            </View>
            <View className="flex-1">
              <Text className="text-sm font-bold">{t.home.samplePriorityTitle}</Text>
              <Text className="text-xs text-muted-foreground" numberOfLines={2}>
                {t.home.samplePrioritySubtitle}
              </Text>
            </View>
            <Text className="text-base font-bold text-destructive">!</Text>
            <ChevronRight size={18} color={palette.fg3} />
          </Card>
        </View>
      </ScrollView>

      <ConfirmModal
        open={logoutOpen}
        onOpenChange={setLogoutOpen}
        icon={LogOut}
        tone="destructive"
        title={t.home.logoutTitle}
        description={t.home.logoutDescription}
        confirmText={t.home.logoutConfirm}
        cancelText={t.common.cancel}
        onConfirm={() => {
          setLogoutOpen(false)
          // RootNavigator switches to the Auth stack when isAuthenticated flips
          postLogout()
        }}
      />
    </View>
  )
}
