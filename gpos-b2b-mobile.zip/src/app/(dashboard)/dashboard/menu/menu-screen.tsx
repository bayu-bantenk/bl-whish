import { useNavigation } from '@react-navigation/native'
import { ChevronRight, CloudUpload, Settings } from 'lucide-react-native'
import * as React from 'react'
import { Pressable, ScrollView, View } from 'react-native'
import Config from 'react-native-config'
import { SafeAreaView } from 'react-native-safe-area-context'

import { Avatar, Card, Text } from '@/components/ui'
import { translate, useTranslation } from '@/shared/dictionaries'
import { useDexain } from '@/shared/styles'
import { useAuthSession } from '@/shared/utils/auth'
import { dashMobileNav, type DashNav } from '@/shared/utils/menus'

import pkg from '../../../../../package.json'

/** Menu urls that live in other tabs rather than this stack. */
const tabRoutes: Record<string, string> = {
  Home: 'HomeTab',
  User: 'UserTab',
  Role: 'RoleTab',
}

export function MenuScreen() {
  const navigation = useNavigation<any>()
  const { session } = useAuthSession()
  const palette = useDexain()
  const { t } = useTranslation()

  const name = session?.name || t.common.user
  const initials = name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()

  const items = dashMobileNav.filter((item) => item.url !== 'Home')

  const openItem = (item: DashNav) => {
    const tab = tabRoutes[item.url]
    if (tab) {
      navigation.navigate(tab)
    } else {
      navigation.navigate(item.url)
    }
  }

  return (
    <View className="flex-1 bg-background">
      <SafeAreaView edges={['top']} className="bg-card" />

      {/* Header */}
      <View className="border-b border-border bg-card px-4 pb-3 pt-1">
        <View className="flex-row items-center justify-between">
          <View>
            <Text className="text-xl font-bold">{t.menu.title}</Text>
            <Text className="text-xs text-muted-foreground">
              {Config.APP_NAME ?? 'Hexenrn'} v{pkg.version}
            </Text>
          </View>
          <View className="flex-row items-center gap-2">
            {/* Sample status chip — wire to real pending state per project */}
            <View className="rounded-full bg-warning-soft px-3 py-1">
              <Text className="text-xs font-semibold text-warning">
                {translate(t.common.pendingBadge, { count: 1 })}
              </Text>
            </View>
            <Pressable
              accessibilityRole="button"
              className="h-9 w-9 items-center justify-center rounded-md active:bg-accent"
            >
              <CloudUpload size={20} color={palette.fg2} />
            </Pressable>
          </View>
        </View>
      </View>

      <ScrollView contentContainerClassName="px-4 py-4 pb-8">
        {/* User card -> profile */}
        <Pressable
          accessibilityRole="button"
          onPress={() => navigation.navigate('Profile')}
        >
          <Card className="flex-row items-center gap-3 p-4">
            <Avatar className="h-11 w-11 bg-primary">
              <Text className="font-bold text-primary-foreground">{initials}</Text>
            </Avatar>
            <View className="flex-1">
              <Text className="text-base font-bold">{name}</Text>
              <Text className="text-xs text-muted-foreground" numberOfLines={1}>
                {t.common.employeeBadge}
                {session?.email ? ` · ${session.email}` : ''}
              </Text>
            </View>
          </Card>
        </Pressable>

        <Text className="mb-2 mt-5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {t.menu.features}
        </Text>

        <View className="gap-2.5">
          {items.map((item) => (
            <Pressable
              key={item.url}
              accessibilityRole="button"
              onPress={() => openItem(item)}
            >
              <Card className="flex-row items-center gap-3 p-3.5 active:bg-accent">
                <View className="h-10 w-10 items-center justify-center rounded-md bg-accent">
                  <item.icon size={18} color={palette.brand} />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold">
                    {item.key ? t.nav[item.key].title : item.title}
                  </Text>
                  {item.key || item.subtitle ? (
                    <Text className="text-xs text-muted-foreground">
                      {item.key ? t.nav[item.key].subtitle : item.subtitle}
                    </Text>
                  ) : null}
                </View>
                <ChevronRight size={18} color={palette.fg3} />
              </Card>
            </Pressable>
          ))}
        </View>

        <Text className="mb-2 mt-5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {t.menu.others}
        </Text>

        <Pressable
          accessibilityRole="button"
          onPress={() => navigation.navigate('Settings')}
        >
          <Card className="flex-row items-center gap-3 p-3.5 active:bg-accent">
            <View className="h-10 w-10 items-center justify-center rounded-md bg-muted">
              <Settings size={18} color={palette.fg2} />
            </View>
            <View className="flex-1">
              <Text className="text-sm font-bold">{t.settings.title}</Text>
              <Text className="text-xs text-muted-foreground">
                {t.menu.settingsSubtitle}
              </Text>
            </View>
            <ChevronRight size={18} color={palette.fg3} />
          </Card>
        </Pressable>
      </ScrollView>
    </View>
  )
}
