import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { Home, LifeBuoy, Menu, UserRound } from 'lucide-react-native'
import * as React from 'react'

import { HomeScreen } from '@/app/(dashboard)/dashboard/home/home-screen'
import { MenuScreen } from '@/app/(dashboard)/dashboard/menu/menu-screen'
import { SettingsScreen } from '@/app/(dashboard)/dashboard/settings/settings-screen'
import type {
  DashboardTabParamList,
  MenuStackParamList,
  RoleStackParamList,
  UserStackParamList,
} from '@/app/navigation-types'
import { TabBarIcon } from '@/components/organisms/navigation/bottom-tabs'
import ApiKeyListView from '@/packages/api-key/presentation/api-key.list'
import AttributeListView from '@/packages/attribute/presentation/attribute.list'
import AuditLogListView from '@/packages/audit-log/presentation/audit-log.list'
import PermissionSetListView from '@/packages/permission-set/presentation/permission-set.list'
import RoleListView from '@/packages/role/presentation/role.list'
import UserFormView from '@/packages/user/presentation/user.form'
import UserListView from '@/packages/user/presentation/user.list'
import UserProfileView from '@/packages/user/presentation/user.profile'
import WorkflowListView from '@/packages/workflow/presentation/workflow.list'
import { useTranslation } from '@/shared/dictionaries'
import { useDexain } from '@/shared/styles'

const Tab = createBottomTabNavigator<DashboardTabParamList>()
const UserStack = createNativeStackNavigator<UserStackParamList>()
const RoleStack = createNativeStackNavigator<RoleStackParamList>()
const MenuStack = createNativeStackNavigator<MenuStackParamList>()

function UserNavigator() {
  return (
    <UserStack.Navigator screenOptions={{ headerShown: false }}>
      <UserStack.Screen name="UserList" component={UserListView} />
      <UserStack.Screen name="UserCreate" component={UserFormView} />
      <UserStack.Screen name="UserUpdate" component={UserFormView} />
    </UserStack.Navigator>
  )
}

function RoleNavigator() {
  return (
    <RoleStack.Navigator screenOptions={{ headerShown: false }}>
      <RoleStack.Screen name="RoleList" component={RoleListView} />
    </RoleStack.Navigator>
  )
}

/**
 * "Semua Fitur" stack: the menu list plus every feature screen it opens.
 * Feature screens registered here use the route names from
 * `dashboardRoute` so `dashMobileNav` urls resolve directly.
 */
function MenuNavigator() {
  return (
    <MenuStack.Navigator screenOptions={{ headerShown: false }}>
      <MenuStack.Screen name="MenuList" component={MenuScreen} />
      <MenuStack.Screen name="Profile" component={UserProfileView} />
      <MenuStack.Screen name="Settings" component={SettingsScreen} />
      <MenuStack.Screen name="PermissionSet" component={PermissionSetListView} />
      <MenuStack.Screen name="AuditLog" component={AuditLogListView} />
      <MenuStack.Screen name="Attribute" component={AttributeListView} />
      <MenuStack.Screen name="ApiKey" component={ApiKeyListView} />
      <MenuStack.Screen name="Workflow" component={WorkflowListView} />
    </MenuStack.Navigator>
  )
}

export function DashboardNavigator() {
  const palette = useDexain()
  const { t } = useTranslation()

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: palette.brand,
        tabBarInactiveTintColor: palette.fg3,
        tabBarStyle: {
          backgroundColor: palette.bgSurface,
          borderTopColor: palette.border,
        },
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeScreen}
        options={{
          title: t.tabs.home,
          tabBarIcon: ({ color }) => <TabBarIcon icon={Home} color={color} />,
        }}
      />
      <Tab.Screen
        name="UserTab"
        component={UserNavigator}
        options={{
          title: t.tabs.users,
          // Reset the nested stack when leaving the tab, so re-entering
          // always lands on the list instead of a previously pushed screen.
          popToTopOnBlur: true,
          tabBarIcon: ({ color }) => <TabBarIcon icon={UserRound} color={color} />,
        }}
      />
      <Tab.Screen
        name="RoleTab"
        component={RoleNavigator}
        options={{
          title: t.tabs.roles,
          popToTopOnBlur: true,
          tabBarIcon: ({ color }) => <TabBarIcon icon={LifeBuoy} color={color} />,
        }}
      />
      <Tab.Screen
        name="MenuTab"
        component={MenuNavigator}
        options={{
          title: t.tabs.menu,
          popToTopOnBlur: true,
          tabBarIcon: ({ color }) => <TabBarIcon icon={Menu} color={color} />,
        }}
      />
    </Tab.Navigator>
  )
}
