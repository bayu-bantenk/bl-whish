import { DefaultTheme, NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import * as React from 'react'

import { AuthNavigator } from '@/app/(auth)/auth-navigator'
import { DashboardNavigator } from '@/app/(dashboard)/dashboard-navigator'
import type { RootStackParamList } from '@/app/navigation-types'
import { useDexain } from '@/shared/styles'
import { useAuthSession } from '@/shared/utils/auth'

const Stack = createNativeStackNavigator<RootStackParamList>()

export function RootNavigator() {
  const { isAuthenticated, isHydrated, hydrate } = useAuthSession()
  const palette = useDexain()

  // Dexain theme for the navigation chrome, following the active brand.
  const navTheme = React.useMemo(
    () => ({
      ...DefaultTheme,
      dark: palette.scheme === 'dark',
      colors: {
        ...DefaultTheme.colors,
        primary: palette.brand,
        background: palette.bgApp,
        card: palette.bgSurface,
        text: palette.fg1,
        border: palette.border,
        notification: palette.danger,
      },
    }),
    [palette]
  )

  React.useEffect(() => {
    hydrate()
  }, [hydrate])

  // Wait for the persisted session before picking a flow, otherwise a
  // logged-in user would flash the Auth stack on every cold start.
  if (!isHydrated) {
    return null
  }

  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isAuthenticated ? (
          <Stack.Screen name="Dashboard" component={DashboardNavigator} />
        ) : (
          <Stack.Screen name="Auth" component={AuthNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  )
}
