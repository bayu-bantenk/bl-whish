import { createNativeStackNavigator } from '@react-navigation/native-stack'
import * as React from 'react'

import type { AuthStackParamList } from '@/app/navigation-types'
import ForgotView from '@/packages/auth/presentation/forgot'
import LoginView from '@/packages/auth/presentation/login'
import RegisterView from '@/packages/auth/presentation/register'
import ResetView from '@/packages/auth/presentation/reset'

const Stack = createNativeStackNavigator<AuthStackParamList>()

export function AuthNavigator() {
  return (
    <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginView} />
      <Stack.Screen name="Register" component={RegisterView} />
      <Stack.Screen name="Forgot" component={ForgotView} />
      <Stack.Screen name="Reset" component={ResetView} />
    </Stack.Navigator>
  )
}
