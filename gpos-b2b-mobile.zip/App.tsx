import './global.css'

import React from 'react'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import { SafeAreaProvider } from 'react-native-safe-area-context'

import { RootNavigator } from '@/app'
import { GlobalProvider } from '@/shared/providers'

function App(): React.JSX.Element {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <GlobalProvider>
          <RootNavigator />
        </GlobalProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  )
}

export default App
