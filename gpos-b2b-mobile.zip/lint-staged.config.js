module.exports = {
  'src/**/*.{ts,tsx}': ['eslint --fix --quiet', 'prettier --write'],
}
